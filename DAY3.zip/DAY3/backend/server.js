const express = require('express');
const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Database connection
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'Felix300512#',
  database: 'smartpark_cwsms',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// JWT Secret - Should be in environment variables in production
const JWT_SECRET = 'your_jwt_secret_key';

// Middleware to verify token
const authenticate = (req, res, next) => {
  const token = req.headers['authorization']?.split(' ')[1]; // Expecting "Bearer <token>"
  if (!token) return res.status(401).json({ error: 'Unauthorized' });

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ error: 'Forbidden' });
    req.user = user;
    next();
  });
};

// Login endpoint
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }

  // Hardcoded credentials - In production, use database authentication
  if (username === 'admin' && password === '1234') {
    const token = jwt.sign({ username: 'admin' }, JWT_SECRET, { expiresIn: '1h' });
    return res.json({ token });
  }
  
  res.status(401).json({ error: 'Invalid credentials' });
});

// Cars endpoints
app.post('/api/cars', authenticate, async (req, res) => {
  const { plate_number, car_type, car_size, driver_name, phone_number } = req.body;
  
  if (!plate_number || !car_type || !car_size || !driver_name || !phone_number) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  try {
    const [result] = await pool.query(
      'INSERT INTO cars (plate_number, car_type, car_size, driver_name, phone_number) VALUES (?, ?, ?, ?, ?)',
      [plate_number, car_type, car_size, driver_name, phone_number]
    );
    res.status(201).json({ 
      message: 'Car added successfully',
      id: result.insertId 
    });
  } catch (error) {
    console.error(error);
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ error: 'Car already exists' });
    }
    res.status(500).json({ error: 'Database error' });
  }
});

app.get('/api/cars', authenticate, async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM cars ORDER BY plate_number ASC');
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Database error' });
  }
});

// ... (existing imports and setup)

// Update car endpoint
app.put('/api/cars/:plate_number', authenticate, async (req, res) => {
  const { plate_number } = req.params;
  const { car_type, car_size, driver_name, phone_number } = req.body;

  if (!car_type || !car_size || !driver_name || !phone_number) {
    return res.status(400).json({ error: 'All fields are required for update' });
  }

  try {
    const [result] = await pool.query(
      'UPDATE cars SET car_type = ?, car_size = ?, driver_name = ?, phone_number = ? WHERE plate_number = ?',
      [car_type, car_size, driver_name, phone_number, plate_number]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Car not found' });
    }
    res.json({ message: 'Car updated successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Database error', details: error.message });
  }
});

// Delete car endpoint
app.delete('/api/cars/:plate_number', authenticate, async (req, res) => {
  const { plate_number } = req.params;

  try {
    const [result] = await pool.query('DELETE FROM cars WHERE plate_number = ?', [plate_number]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Car not found' });
    }
    res.json({ message: 'Car deleted successfully' });
  } catch (error) {
    console.error(error);
    // Handle potential foreign key constraint errors if other tables depend on cars
    if (error.code === 'ER_ROW_IS_REFERENCED_2') {
      return res.status(409).json({ error: 'Cannot delete car: associated services exist' });
    }
    res.status(500).json({ error: 'Database error', details: error.message });
  }
});

// ... (rest of your existing code)

// Packages endpoints
app.get('/api/packages', authenticate, async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM packages ORDER BY package_number ASC');
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error', details: error.message });
  }
});

// Service endpoints
app.post('/api/services', authenticate, async (req, res) => {
  const { plate_number, package_number } = req.body;
  
  if (!plate_number || !package_number) {
    return res.status(400).json({ error: 'Plate number and package number are required' });
  }

  try {
    // Start transaction
    const connection = await pool.getConnection();
    await connection.beginTransaction();

    try {
      // Check if car exists
      const [car] = await connection.query('SELECT * FROM cars WHERE plate_number = ?', [plate_number]);
      if (car.length === 0) {
        throw { status: 404, message: 'Car not found' };
      }

      // Check if package exists
      const [package] = await connection.query('SELECT * FROM packages WHERE package_number = ?', [package_number]);
      if (package.length === 0) {
        throw { status: 404, message: 'Package not found' };
      }

      // Record service
      const [serviceResult] = await connection.query(
        'INSERT INTO service_details (plate_number, package_number) VALUES (?, ?)',
        [plate_number, package_number]
      );
      
      const record_number = serviceResult.insertId;
      
      // Record payment
      await connection.query(
        'INSERT INTO payments (amount_paid, record_number) VALUES (?, ?)',
        [package[0].package_price, record_number]
      );
      
      await connection.commit();
      res.status(201).json({ 
        message: 'Service recorded successfully',
        record_number 
      });
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  } catch (error) {
    console.error(error);
    if (error.status) {
      return res.status(error.status).json({ error: error.message });
    }
    res.status(500).json({ error: 'Server error', details: error.message });
  }
});

app.get('/api/services', authenticate, async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT 
        s.record_number, 
        c.plate_number, 
        c.driver_name, 
        c.phone_number, 
        p.package_name, 
        p.package_description, 
        p.package_price, 
        s.service_date, 
        pm.payment_date
      FROM service_details s
      JOIN cars c ON s.plate_number = c.plate_number
      JOIN packages p ON s.package_number = p.package_number
      JOIN payments pm ON s.record_number = pm.record_number
      ORDER BY s.service_date DESC
    `);
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error', details: error.message });
  }
});

// Update service endpoint
app.put('/api/services/:record_number', authenticate, async (req, res) => {
  const { record_number } = req.params;
  const { plate_number, package_number } = req.body;
  
  if (!plate_number || !package_number) {
    return res.status(400).json({ error: 'Plate number and package number are required' });
  }

  try {
    // Start transaction
    const connection = await pool.getConnection();
    await connection.beginTransaction();

    try {
      // Check if service exists
      const [service] = await connection.query(
        'SELECT * FROM service_details WHERE record_number = ?', 
        [record_number]
      );
      if (service.length === 0) {
        throw { status: 404, message: 'Service not found' };
      }

      // Check if car exists
      const [car] = await connection.query(
        'SELECT * FROM cars WHERE plate_number = ?', 
        [plate_number]
      );
      if (car.length === 0) {
        throw { status: 404, message: 'Car not found' };
      }

      // Check if package exists
      const [pkg] = await connection.query(
        'SELECT * FROM packages WHERE package_number = ?', 
        [package_number]
      );
      if (pkg.length === 0) {
        throw { status: 404, message: 'Package not found' };
      }

      // Update service
      await connection.query(
        'UPDATE service_details SET plate_number = ?, package_number = ? WHERE record_number = ?',
        [plate_number, package_number, record_number]
      );
      
      // Update payment amount if package price changed
      await connection.query(
        'UPDATE payments SET amount_paid = ? WHERE record_number = ?',
        [pkg[0].package_price, record_number]
      );
      
      await connection.commit();
      res.json({ 
        message: 'Service updated successfully',
        record_number 
      });
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  } catch (error) {
    console.error(error);
    if (error.status) {
      return res.status(error.status).json({ error: error.message });
    }
    res.status(500).json({ error: 'Server error', details: error.message });
  }
});

// Delete service endpoint
app.delete('/api/services/:record_number', authenticate, async (req, res) => {
  const { record_number } = req.params;

  try {
    // Start transaction
    const connection = await pool.getConnection();
    await connection.beginTransaction();

    try {
      // Check if service exists
      const [service] = await connection.query(
        'SELECT * FROM service_details WHERE record_number = ?', 
        [record_number]
      );
      if (service.length === 0) {
        throw { status: 404, message: 'Service not found' };
      }

      // Delete payment first (due to foreign key constraint)
      await connection.query(
        'DELETE FROM payments WHERE record_number = ?',
        [record_number]
      );
      
      // Then delete service
      await connection.query(
        'DELETE FROM service_details WHERE record_number = ?',
        [record_number]
      );
      
      await connection.commit();
      res.json({ 
        message: 'Service deleted successfully',
        record_number 
      });
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  } catch (error) {
    console.error(error);
    if (error.status) {
      return res.status(error.status).json({ error: error.message });
    }
    res.status(500).json({ error: 'Server error', details: error.message });
  }
});


// Reports endpoint
app.get('/api/reports/daily', authenticate, async (req, res) => {
  try {
    const dateFilter = req.query.date || new Date().toISOString().split('T')[0];
    
    const [rows] = await pool.query(`
      SELECT 
        c.plate_number,
        p.package_name,
        p.package_description,
        pm.amount_paid,
        s.service_date
      FROM service_details s
      JOIN cars c ON s.plate_number = c.plate_number
      JOIN packages p ON s.package_number = p.package_number
      JOIN payments pm ON s.record_number = pm.record_number
      WHERE DATE(s.service_date) = ?
      ORDER BY s.service_date DESC
    `, [dateFilter]);
    
    res.json(rows || []);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error', details: error.message });
  }
});

app.get('/api/reports/download', authenticate, async (req, res) => {
  try {
    const dateFilter = req.query.date || new Date().toISOString().split('T')[0];
    
    const [rows] = await pool.query(`
      SELECT 
        c.plate_number,
        p.package_name,
        p.package_description,
        pm.amount_paid,
        s.service_date
      FROM service_details s
      JOIN cars c ON s.plate_number = c.plate_number
      JOIN packages p ON s.package_number = p.package_number
      JOIN payments pm ON s.record_number = pm.record_number
      WHERE DATE(s.service_date) = ?
      ORDER BY s.service_date DESC
    `, [dateFilter]);
    
    // Convert to CSV
    let csv = 'Plate Number,Package Name,Description,Amount Paid (RWF),Service Date\n';
    rows.forEach(row => {
      csv += `"${row.plate_number}","${row.package_name}","${row.package_description}",${row.amount_paid},"${new Date(row.service_date).toLocaleString()}"\n`;
    });
    
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename=carwash_report_${dateFilter}.csv`);
    res.send(csv);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error', details: error.message });
  }
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});