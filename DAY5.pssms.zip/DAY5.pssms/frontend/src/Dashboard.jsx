import { useState, useEffect } from 'react'; // Import useState and useEffect
import { Link } from 'react-router-dom';
import axios from 'axios'; // Import axios for API calls

export default function Dashboard() {
  const [dashboardData, setDashboardData] = useState({
    availableSlots: 0,
    occupiedSlots: 0,
    activeSessions: 0,
    todayRevenue: 0
  });

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const [slotsRes, recordsRes, paymentsRes] = await Promise.all([
          axios.get('http://localhost:5000/api/slots'),
          axios.get('http://localhost:5000/api/records'),
          axios.get('http://localhost:5000/api/payments')
        ]);

        const availableSlots = slotsRes.data.filter(slot => slot.slotstatus === 'available').length;
        const occupiedSlots = slotsRes.data.filter(slot => slot.slotstatus === 'occupied').length;
        const activeSessions = recordsRes.data.filter(record => !record.exittime).length;
        
        const today = new Date().toISOString().split('T')[0];
        const todayRevenue = paymentsRes.data
          .filter(payment => new Date(payment.paymentdate).toISOString().split('T')[0] === today)
          .reduce((sum, payment) => sum + payment.amountpaid, 0);

        setDashboardData({
          availableSlots,
          occupiedSlots,
          activeSessions
        });
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      }
    };
    fetchDashboardData();
  }, []);

  return (
    <div className="bg-white shadow rounded-lg p-6">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Dashboard</h2>
      <p className="text-gray-600 mb-8">Welcome to SmartPark Parking Slot Management System</p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {/* Available Slots Card */}
        <div className="bg-green-50 border border-green-200 rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
          <h3 className="text-lg font-medium text-green-800 mb-2">Available Slots</h3>
          <p className="text-3xl font-bold text-green-600">{dashboardData.availableSlots}</p>
        </div>

        {/* Occupied Slots Card */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
          <h3 className="text-lg font-medium text-blue-800 mb-2">Occupied Slots</h3>
          <p className="text-3xl font-bold text-blue-600">{dashboardData.occupiedSlots}</p>
        </div>

        {/* Active Sessions Card */}
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
          <h3 className="text-lg font-medium text-yellow-800 mb-2">Active Sessions</h3>
          <p className="text-3xl font-bold text-yellow-600">{dashboardData.activeSessions}</p>
        </div>

      </div>

      {/* Quick Actions */}
      <div className="space-y-4">
        <h3 className="text-lg font-medium text-gray-900">Quick Actions</h3>
        <div className="flex flex-wrap gap-4">
          <Link
            to="/cars"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            Register New Vehicle
          </Link>
          <Link
            to="/parking"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
          >
            Start Parking Session
          </Link>

        </div>
      </div>
    </div>
  );
}