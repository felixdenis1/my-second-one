import { useState, useEffect } from 'react';
import axios from 'axios';

// Configure axios globally for consistency
axios.defaults.baseURL = 'http://localhost:5000'; // Your backend server URL
axios.defaults.withCredentials = true; // Essential for sending session cookies

export default function CarManagement() {

  axios.defaults.withCredentials = true;
  
  const [cars, setCars] = useState([]);
  const [formData, setFormData] = useState({
    plateno: '',       // Matches backend 'plateno'
    drivername: '',    // Matches backend 'drivername'
    phonenumber: ''    // Matches backend 'phonenumber'
  });
  const [editing, setEditing] = useState(false); // Changed to boolean, editing will be true/false
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchCars();
  }, []);

  const fetchCars = async () => {
    try {
      // No 'Authorization' header needed for session-based authentication
      const { data } = await axios.get('/vehicles');
      setCars(data); // Backend returns data with 'plateno', 'drivername', 'phonenumber'
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to fetch cars');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      if (editing) {
        // For editing, send only the fields that are allowed to be updated.
        // Plate number is generally the primary key and often not changed directly.
        await axios.put(`/vehicles/${formData.plateno}`, {
          drivername: formData.drivername,
          phonenumber: formData.phonenumber
        });
      } else {
        // For new car, send all required fields
        await axios.post('/vehicles', formData);
      }
      // Reset form fields
      setFormData({
        plateno: '',
        drivername: '',
        phonenumber: ''
      });
      setEditing(false); // Reset editing state
      fetchCars(); // Refresh the list
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to save car');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (car) => {
    // Populate form with car data for editing.
    // 'car' object from backend has 'plateno', 'drivername', 'phonenumber'.
    setFormData({
      plateno: car.plateno,
      drivername: car.drivername,
      phonenumber: car.phonenumber
    });
    setEditing(true); // Set editing mode
  };

  const handleDelete = async (plateno) => {
    if (!window.confirm('Are you sure you want to delete this car?')) return;

    try {
      await axios.delete(`/vehicles/${plateno}`);
      fetchCars(); // Refresh the list
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to delete car');
    }
  };

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-bold text-blue-800 mb-6">Car Management</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Form Section */}
        <div className="bg-white p-6 rounded-2xl shadow-md border border-gray-200">
          <h2 className="text-xl font-semibold text-gray-700 mb-4">
            {editing ? 'Edit Car' : 'Add New Car'}
          </h2>

          {error && (
            <div className="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Input for Plate Number */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Plate Number
              </label>
              <input
                type="text"
                required
                disabled={editing} // Disable plate number input when editing
                className="w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500"
                value={formData.plateno}
                onChange={(e) => setFormData({ ...formData, plateno: e.target.value })}
              />
            </div>

            {/* Input for Driver Name */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Driver Name
              </label>
              <input
                type="text"
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500"
                value={formData.drivername}
                onChange={(e) => setFormData({ ...formData, drivername: e.target.value })}
              />
            </div>

            {/* Input for Phone Number */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Phone Number
              </label>
              <input
                type="text"
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500"
                value={formData.phonenumber}
                onChange={(e) => setFormData({ ...formData, phonenumber: e.target.value })}
              />
            </div>

            {/* Removed car_type and car_size as they are not in your backend 'car' table */}

            <button
              type="submit"
              disabled={loading}
              className={`w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg shadow-sm transition duration-200 ${
                loading ? 'opacity-70 cursor-not-allowed' : ''
              }`}
            >
              {loading ? 'Saving...' : editing ? 'Update Car' : 'Add Car'}
            </button>
          </form>
        </div>

        {/* Table Section */}
        <div className="bg-white p-6 rounded-2xl shadow-md border border-gray-200">
          <h2 className="text-xl font-semibold text-gray-700 mb-4">Registered Cars</h2>

          {cars.length === 0 ? (
            <p className="text-gray-500">No cars registered yet</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200 text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    {/* Updated headers to match backend data */}
                    {['Plate Number', 'Driver Name', 'Phone Number', 'Actions'].map((header, idx) => (
                      <th key={idx} className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {header}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {cars.map((car) => (
                    <tr key={car.plateno} className="hover:bg-gray-50">
                      {/* Accessing data using backend field names */}
                      <td className="px-6 py-3 text-gray-800 font-medium">{car.plateno}</td>
                      <td className="px-6 py-3 text-gray-600">{car.drivername}</td>
                      <td className="px-6 py-3 text-gray-600">{car.phonenumber}</td>
                      <td className="px-6 py-3 space-x-3">
                        <button
                          onClick={() => handleEdit(car)}
                          className="text-blue-600 hover:underline font-medium"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => handleDelete(car.plateno)}
                          className="text-red-600 hover:underline font-medium"
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}