import { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Reports() {
  const [report, setReport] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [dateFilter, setDateFilter] = useState(new Date().toISOString().split('T')[0]);
  const navigate = useNavigate();

  const fetchReport = async () => {
    setLoading(true);
    setError('');
    try {
      const token = localStorage.getItem('token');
      const { data } = await axios.get(
        `http://localhost:5000/api/reports/daily`,
        {
          headers: token ? { Authorization: `Bearer ${token}` } : {},
          params: { date: dateFilter }
        }
      );
      setReport(data);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to fetch report data');
      console.error('Fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReport();
  }, [dateFilter]);

  const exportToCSV = () => {
    if (report.length === 0) {
      setError('No data to export');
      return;
    }

    const headers = [
      'Record ID', 'Plate Number', 'Driver Name', 'Slot Number',
      'Entry Time', 'Exit Time', 'Duration (Minutes)',
      'Amount Paid (RWF)', 'Payment Date'
    ];

    const csvRows = report.map(item => {
      const amountPaidForCsv = item.amountpaid !== null ? parseFloat(item.amountpaid).toFixed(2) : '';
      const durationForCsv = item.duration_minutes !== null ? item.duration_minutes : '';

      return [
        `"${item.recordid || ''}"`,
        `"${item.platenumber || ''}"`, // <-- CHANGED THIS LINE FROM item.plateno
        `"${item.drivername || ''}"`,
        `"${item.slotnumber || ''}"`,
        `"${item.entrytime ? new Date(item.entrytime).toLocaleString() : ''}"`,
        `"${item.exittime ? new Date(item.exittime).toLocaleString() : 'Active'}"`,
        `"${durationForCsv}"`,
        `"${amountPaidForCsv}"`,
        `"${item.paymentdate ? new Date(item.paymentdate).toLocaleString() : 'N/A'}"`
      ];
    });

    const csvContent = [headers.join(','), ...csvRows.map(row => row.join(','))].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);

    link.setAttribute('href', url);
    link.setAttribute('download', `parking_report_${dateFilter}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return '-';
    return new Date(dateStr).toLocaleString(undefined, {
      year: 'numeric', month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit'
    });
  };

  const totalRevenue = report.reduce((sum, item) => {
    const amount = item.amountpaid !== null ? parseFloat(item.amountpaid) : 0;
    return sum + amount;
  }, 0);

  const totalDurationMinutes = report.reduce((sum, item) => {
    const duration = item.duration_minutes !== null ? parseFloat(item.duration_minutes) : 0;
    return sum + duration;
  }, 0);

  return (
    <div className="container mx-auto p-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <h1 className="text-2xl md:text-3xl font-bold text-gray-800">Daily Parking & Payment Report</h1>
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 w-full md:w-auto">
          <div className="relative w-full sm:w-auto">
            <label htmlFor="report-date" className="block text-sm font-medium text-gray-700 mb-1">
              Report Date
            </label>
            <input
              id="report-date"
              type="date"
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              max={new Date().toISOString().split('T')[0]}
            />
          </div>
          <button
            onClick={exportToCSV}
            disabled={report.length === 0 || loading}
            className={`mt-6 sm:mt-7 px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${report.length === 0 || loading ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            Export CSV
          </button>
        </div>
      </div>

      {error && (
        <div className="mb-4 p-4 bg-red-50 border-l-4 border-red-400 rounded">
          <p className="text-sm text-red-700">{error}</p>
        </div>
      )}

      {loading ? (
        <div className="flex flex-col items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
          <p className="mt-4 text-gray-600">Loading report data...</p>
        </div>
      ) : report.length === 0 ? (
        <div className="bg-white p-8 rounded-lg shadow-md text-center border border-gray-200">
          <h3 className="mt-2 text-lg font-medium text-gray-900">No report data found</h3>
          <p className="mt-1 text-sm text-gray-500">
            {dateFilter === new Date().toISOString().split('T')[0]
              ? "No parking records or payments for today."
              : `No parking records or payments on ${new Date(dateFilter).toLocaleDateString()}.`}
          </p>
          <div className="mt-6">
            <button
              onClick={() => navigate('/parking')}
              className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Go to Parking Management
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Record ID</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Plate Number</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Driver</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Slot</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Entry Time</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Exit Time</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Duration (Mins)</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount Paid</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Payment Date</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {report.map((item) => (
                  <tr key={item.recordid} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{item.recordid}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{item.plateno}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.drivername || '-'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.slotnumber}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{formatDate(item.entrytime)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {item.exittime ? formatDate(item.exittime) : 'Active'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {item.duration_minutes !== null ? item.duration_minutes : '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {item.amountpaid !== null ? `${parseFloat(item.amountpaid).toLocaleString()} RWF` : 'Not Paid'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {item.paymentdate ? formatDate(item.paymentdate) : 'N/A'}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-gray-50">
                <tr>
                  <td colSpan="6" className="px-6 py-3 text-right text-sm font-medium text-gray-900">Total Duration (Completed Sessions):</td>
                  <td className="px-6 py-3 whitespace-nowrap text-sm font-medium text-gray-900">
                    {totalDurationMinutes.toLocaleString()} Mins
                  </td>
                  <td className="px-6 py-3 text-right text-sm font-medium text-gray-900">Total Revenue:</td>
                  <td className="px-6 py-3 whitespace-nowrap text-sm font-medium text-gray-900">
                    {totalRevenue.toLocaleString()} RWF
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}