import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function ParkingSlots() {
    const [slots, setSlots] = useState([]);
    const [showModal, setShowModal] = useState(false);
    const [error, setError] = useState(''); // State for error messages
    const [formData, setFormData] = useState({
        slotnumber: '',
        slotstatus: 'available'
    });

    // Fetch slots on component mount
    useEffect(() => {
        const fetchSlots = async () => {
            try {
                // Use the relative path, axios.defaults.baseURL will handle the full URL
                const response = await axios.get('/slots'); // Added /api/ here as per your backend routes
                setSlots(response.data);
                setError(''); // Clear any previous errors on successful fetch
            } catch (error) {
                console.error('Error fetching parking slots:', error);
                setError(error.response?.data?.message || 'Failed to fetch parking slots.');
            }
        };
        fetchSlots();
    }, []); // Empty dependency array ensures it runs once on mount

    const handleInputChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError(''); // Clear previous errors

        try {
            await axios.post('/slots', formData); // Added /api/ here
            
            setShowModal(false);
            // Re-fetch slots after successful addition
            const response = await axios.get('/slots'); // Added /api/ here
            setSlots(response.data);
            // Reset form
            setFormData({
                slotnumber: '',
                slotstatus: 'available'
            });
        } catch (error) {
            console.error('Error adding parking slot:', error);
            setError(error.response?.data?.message || 'Failed to add parking slot. Does the slot already exist?');
        }
    };

    const updateSlotStatus = async (slotnumber, status) => {
        setError(''); // Clear previous errors
        console.log(`Attempting to send update for slot ${slotnumber} with status:`, status); // Added for debugging
        try {
            // CRITICAL CHANGE: Changed 'status' to 'slotstatus' to match backend expectation
            await axios.put(`/slots/${slotnumber}`, { slotstatus: status }); // Added /api/ here

            // Re-fetch slots after successful update
            const response = await axios.get('/slots'); // Added /api/ here
            setSlots(response.data);
        } catch (error) {
            console.error('Error updating slot status:', error);
            setError(error.response?.data?.message || 'Failed to update slot status.');
        }
    };

    return (
        <div className="bg-white shadow rounded-lg p-6">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-gray-900">Parking Slots</h2>
                <button
                    onClick={() => setShowModal(true)}
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                    Add New Slot
                </button>
            </div>

            {error && (
                <div className="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
                    <strong className="font-bold">Error!</strong>
                    <span className="block sm:inline ml-2">{error}</span>
                    <span className="absolute top-0 bottom-0 right-0 px-4 py-3" onClick={() => setError('')}>
                        <svg className="fill-current h-6 w-6 text-red-500" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><title>Close</title><path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"/></svg>
                    </span>
                </div>
            )}

            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Slot Number
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Status
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Actions
                            </th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {slots.map((slot) => (
                            <tr key={slot.slotnumber}>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                    {slot.slotnumber}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm">
                                    <span
                                        className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                            slot.slotstatus === 'available'
                                                ? 'bg-green-100 text-green-800'
                                                : slot.slotstatus === 'occupied'
                                                ? 'bg-red-100 text-red-800'
                                                : 'bg-yellow-100 text-yellow-800'
                                        }`}
                                    >
                                        {slot.slotstatus}
                                    </span>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 space-x-2">
                                    <button
                                        onClick={() => updateSlotStatus(slot.slotnumber, 'available')}
                                        className={`text-xs px-2 py-1 rounded ${
                                            slot.slotstatus === 'available'
                                                ? 'bg-gray-200 text-gray-700 cursor-not-allowed'
                                                : 'bg-green-500 text-white hover:bg-green-600'
                                        }`}
                                        disabled={slot.slotstatus === 'available'}
                                    >
                                        Mark Available
                                    </button>
                                    <button
                                        onClick={() => updateSlotStatus(slot.slotnumber, 'occupied')}
                                        className={`text-xs px-2 py-1 rounded ${
                                            slot.slotstatus === 'occupied'
                                                ? 'bg-gray-200 text-gray-700 cursor-not-allowed'
                                                : 'bg-red-500 text-white hover:bg-red-600'
                                        }`}
                                        disabled={slot.slotstatus === 'occupied'}
                                    >
                                        Mark Occupied
                                    </button>
                                    <button
                                        onClick={() => updateSlotStatus(slot.slotnumber, 'maintenance')}
                                        className={`text-xs px-2 py-1 rounded ${
                                            slot.slotstatus === 'maintenance'
                                                ? 'bg-gray-200 text-gray-700 cursor-not-allowed'
                                                : 'bg-yellow-500 text-white hover:bg-yellow-600'
                                        }`}
                                        disabled={slot.slotstatus === 'maintenance'}
                                    >
                                        Mark Maintenance
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Add Slot Modal */}
            {showModal && (
                <div className="fixed z-10 inset-0 overflow-y-auto">
                    <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
                        <div className="fixed inset-0 transition-opacity" aria-hidden="true">
                            <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
                        </div>
                        <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
                        <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
                            <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                                <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">Add New Parking Slot</h3>
                                <form onSubmit={handleSubmit}>
                                    <div className="mb-4">
                                        <label htmlFor="slotnumber" className="block text-sm font-medium text-gray-700">
                                            Slot Number
                                        </label>
                                        <input
                                            type="number" // Changed to number type, as slot number is often numeric
                                            name="slotnumber"
                                            id="slotnumber"
                                            className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                                            value={formData.slotnumber}
                                            onChange={handleInputChange}
                                            required
                                        />
                                    </div>
                                    <div className="mb-4">
                                        <label htmlFor="slotstatus" className="block text-sm font-medium text-gray-700">
                                            Status
                                        </label>
                                        <select
                                            id="slotstatus"
                                            name="slotstatus"
                                            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
                                            value={formData.slotstatus}
                                            onChange={handleInputChange}
                                        >
                                            <option value="available">Available</option>
                                            <option value="occupied">Occupied</option>
                                            <option value="maintenance">Maintenance</option>
                                        </select>
                                    </div>
                                    <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                                        <button
                                            type="submit"
                                            className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm"
                                        >
                                            Save
                                        </button>
                                        <button
                                            type="button"
                                            onClick={() => setShowModal(false)}
                                            className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                                        >
                                            Cancel
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}