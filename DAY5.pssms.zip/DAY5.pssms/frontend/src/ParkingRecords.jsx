import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function ParkingRecords() {
  const [records, setRecords] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [slots, setSlots] = useState([]);
  const [showEntryModal, setShowEntryModal] = useState(false);
  const [showExitModal, setShowExitModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [formData, setFormData] = useState({
    platenumber: '',
    slotnumber: ''
  });
  const [paymentData, setPaymentData] = useState({
    amount: '',
    paymentMethod: 'cash'
  });
  const [duration, setDuration] = useState(0);
  const [fee, setFee] = useState(0);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Calculate parking fee (500 RWF per hour, minimum 500 RWF)
  const calculateFee = (entryTime, exitTime) => {
    const entry = new Date(entryTime);
    const exit = new Date(exitTime);
    const diffMs = exit - entry;
    const diffHours = diffMs / (1000 * 60 * 60);
    
    // Minimum charge is 500 RWF (for less than 1 hour)
    if (diffHours <= 1) {
      return 500;
    }
    
    // For more than 1 hour, charge 500 RWF per hour, rounded up
    const hours = Math.ceil(diffHours);
    return hours * 500;
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        setError(''); // Clear previous errors
        const [recordsRes, vehiclesRes, slotsRes] = await Promise.all([
          // Use relative paths as baseURL is configured
          axios.get('/records'),
          axios.get('/vehicles'),
          axios.get('/slots?status=available') // Fetch only available slots
        ]);
        setRecords(recordsRes.data);
        setVehicles(vehiclesRes.data);
        setSlots(slotsRes.data);
      } catch (error) {
        console.error('Error fetching data:', error);
        setError(error.response?.data?.message || 'Failed to fetch parking data.');
      }
    };
    fetchData();
  }, []);

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handlePaymentChange = (e) => {
    setPaymentData({
      ...paymentData,
      [e.target.name]: e.target.value
    });
  };

  const handleEntrySubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    try {
      // 1. Start new parking session
      await axios.post('/records', formData);

      // 2. Update slot status to occupied
      await axios.put(`/slots/${formData.slotnumber}`, {
        slotstatus: 'occupied' // Ensure your backend expects 'slotstatus' not just 'status'
      });

      setShowEntryModal(false);
      setFormData({ platenumber: '', slotnumber: '' });

      // 3. Refresh data
      const [recordsRes, slotsRes] = await Promise.all([
        axios.get('/records'),
        axios.get('/slots?status=available')
      ]);

      setRecords(recordsRes.data);
      setSlots(slotsRes.data);
      setSuccess('Parking session started successfully!');
    } catch (error) {
      console.error('Error starting parking session:', error);
      setError(error.response?.data?.message || 'Failed to start parking session.');
    }
  };

  const handleExit = async (record) => {
    setSelectedRecord(record);

    // Calculate duration and fee
    const exitTime = new Date();
    const durationHours = (exitTime - new Date(record.entrytime)) / (1000 * 60 * 60);
    const calculatedFee = calculateFee(record.entrytime, exitTime);

    setDuration(durationHours);
    setFee(calculatedFee);
    setPaymentData({
      amount: calculatedFee.toFixed(2),
      paymentMethod: 'cash'
    });

    setShowExitModal(true);
  };

  const handleExitSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    try {
      // 1. End parking session (update exit time in the record)
      await axios.put(`/records/${selectedRecord.recordid}/exit`); // Assuming this endpoint

      // 2. Update slot status to available
      await axios.put(`/slots/${selectedRecord.slotnumber}`, {
        slotstatus: 'available' // Ensure your backend expects 'slotstatus'
      });

      setShowExitModal(false);
      setShowPaymentModal(true); // Proceed to payment modal
      setSuccess('Parking session ended successfully. Proceeding to payment.');
    } catch (error) {
      console.error('Error ending parking session:', error);
      setError(error.response?.data?.message || 'Failed to end parking session.');
    }
  };

  const handlePaymentSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    try {
      // 1. Process payment
      await axios.post('/payments', {
        recordid: selectedRecord.recordid,
        amountpaid: parseFloat(paymentData.amount),
        paymentmethod: paymentData.paymentMethod
      });

      setShowPaymentModal(false);

      // 2. Refresh data
      const [recordsRes, slotsRes] = await Promise.all([
        axios.get('/records'),
        axios.get('/slots?status=available')
      ]);

      setRecords(recordsRes.data);
      setSlots(slotsRes.data);
      setSuccess('Payment processed successfully!');
    } catch (error) {
      console.error('Error processing payment:', error);
      setError(error.response?.data?.message || 'Payment failed.');
    }
  };

  return (
    <div className="bg-white shadow rounded-lg p-6">
      {error && (
        <div className="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
          <strong className="font-bold">Error!</strong>
          <span className="block sm:inline ml-2">{error}</span>
          <span className="absolute top-0 bottom-0 right-0 px-4 py-3 cursor-pointer" onClick={() => setError('')}>
            <svg className="fill-current h-6 w-6 text-red-500" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><title>Close</title><path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"/></svg>
          </span>
        </div>
      )}
      {success && (
        <div className="mb-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative">
          <strong className="font-bold">Success!</strong>
          <span className="block sm:inline ml-2">{success}</span>
          <span className="absolute top-0 bottom-0 right-0 px-4 py-3 cursor-pointer" onClick={() => setSuccess('')}>
            <svg className="fill-current h-6 w-6 text-green-500" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><title>Close</title><path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"/></svg>
          </span>
        </div>
      )}

      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Parking Records</h2>
        <button
          onClick={() => setShowEntryModal(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
        >
          New Parking Session
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Record ID</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Plate Number</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Driver</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Slot</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Entry Time</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Exit Time</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {records.map(record => {
              const vehicle = vehicles.find(v => v.plateno === record.platenumber);
              return (
                <tr key={record.recordid}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{record.recordid}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{record.platenumber}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {vehicle ? vehicle.drivername : 'N/A'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{record.slotnumber}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(record.entrytime).toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {record.exittime ? new Date(record.exittime).toLocaleString() : 'Active'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                      ${!record.exittime ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                      {!record.exittime ? 'Active' : 'Completed'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    {!record.exittime ? (
                      <button
                        onClick={() => handleExit(record)}
                        className="text-red-600 hover:text-red-900 mr-2"
                      >
                        End Session
                      </button>
                    ) : (
                      <span className="text-gray-400">Completed</span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* New Parking Session Modal */}
      {showEntryModal && (
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">New Parking Session</h3>
                <form onSubmit={handleEntrySubmit}>
                  <div className="mb-4">
                    <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="platenumber">
                      Vehicle
                    </label>
                    <select
                      className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                      id="platenumber"
                      name="platenumber"
                      value={formData.platenumber}
                      onChange={handleInputChange}
                      required
                    >
                      <option value="">Select a vehicle</option>
                      {vehicles.map(vehicle => (
                        <option key={vehicle.plateno} value={vehicle.plateno}>
                          {vehicle.plateno} - {vehicle.drivername}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="mb-4">
                    <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="slotnumber">
                      Available Slot
                    </label>
                    <select
                      className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                      id="slotnumber"
                      name="slotnumber"
                      value={formData.slotnumber}
                      onChange={handleInputChange}
                      required
                    >
                      <option value="">Select a slot</option>
                      {slots.map(slot => (
                        <option key={slot.slotnumber} value={slot.slotnumber}>
                          Slot {slot.slotnumber}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button
                      type="submit"
                      className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm"
                    >
                      Start Session
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowEntryModal(false)}
                      className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Exit Confirmation Modal */}
      {showExitModal && selectedRecord && (
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">End Parking Session</h3>
                <div className="mb-4">
                  <p className="text-gray-700"><span className="font-semibold">Plate Number:</span> {selectedRecord.platenumber}</p>
                  <p className="text-gray-700"><span className="font-semibold">Slot Number:</span> {selectedRecord.slotnumber}</p>
                  <p className="text-gray-700"><span className="font-semibold">Entry Time:</span> {new Date(selectedRecord.entrytime).toLocaleString()}</p>
                  <p className="text-gray-700"><span className="font-semibold">Duration:</span> {duration.toFixed(2)} hours</p>
                  <p className="text-gray-700"><span className="font-semibold">Fee:</span> {fee.toFixed(2)} RWF</p>
                </div>
                <form onSubmit={handleExitSubmit}>
                  <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button
                      type="submit"
                      className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm"
                    >
                      Confirm Exit
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowExitModal(false)}
                      className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Payment Modal */}
      {showPaymentModal && selectedRecord && (
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">Process Payment</h3>
                <div className="mb-4">
                  <p className="text-gray-700"><span className="font-semibold">Record ID:</span> {selectedRecord.recordid}</p>
                  <p className="text-gray-700"><span className="font-semibold">Plate Number:</span> {selectedRecord.platenumber}</p>
                  <p className="text-gray-700"><span className="font-semibold">Duration:</span> {duration.toFixed(2)} hours</p>
                  <p className="text-gray-700"><span className="font-semibold">Total Fee:</span> {fee.toFixed(2)} RWF</p>
                </div>
                <form onSubmit={handlePaymentSubmit}>
                  <div className="mb-4">
                    <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="amount">
                      Amount Paid
                    </label>
                    <input
                      className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                      id="amount"
                      type="number"
                      step="0.01"
                      min={fee.toFixed(2)}
                      name="amount"
                      value={paymentData.amount}
                      onChange={handlePaymentChange}
                      required
                    />
                  </div>
                  <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button
                      type="submit"
                      className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm"
                    >
                      Process Payment
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowPaymentModal(false)}
                      className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}