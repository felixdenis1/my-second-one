create database pssms;
use pssms;

-- Table 1: users (for authentication)
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL -- Store hashed passwords only!
);

-- Table 2: parkingslot
CREATE TABLE parkingslot (
  slotnumber INT PRIMARY KEY,
  slotstatus VARCHAR(20) NOT NULL CHECK (slotstatus IN ('occupied', 'available', 'maintenance'))
);

-- Table 3: car
CREATE TABLE car (
  plateno VARCHAR(20) PRIMARY KEY,
  drivername VARCHAR(100) NOT NULL,
  phonenumber VARCHAR(15) NOT NULL
);

-- Table 4: parkingrecord
CREATE TABLE parkingrecord (
  recordid INT AUTO_INCREMENT PRIMARY KEY,
  platenumber VARCHAR(20) NOT NULL,
  slotnumber INT NOT NULL,
  entrytime DATETIME NOT NULL,
  exittime DATETIME,
  duration INT,
  FOREIGN KEY (platenumber) REFERENCES car(plateno) ON DELETE CASCADE,
  FOREIGN KEY (slotnumber) REFERENCES parkingslot(slotnumber) ON DELETE CASCADE
);

-- Table 5: payment
CREATE TABLE payment (
  paymentid INT AUTO_INCREMENT PRIMARY KEY,
  platenumber VARCHAR(20) NOT NULL,
  recordid INT NOT NULL,
  amountpaid DECIMAL(10, 2) NOT NULL,
  paymentdate DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (platenumber) REFERENCES car(plateno) ON DELETE CASCADE,
  FOREIGN KEY (recordid) REFERENCES parkingrecord(recordid) ON DELETE CASCADE
);