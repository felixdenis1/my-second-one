const express = require('express');
const mysql = require('mysql2/promise'); // Using promise-based API for async/await
const bodyParser = require('body-parser');
const cors = require('cors');
const session = require('express-session');
const bcrypt = require('bcrypt');
const MySQLStore = require('express-mysql-session')(session); // To store sessions in MySQL

const app = express();

// Middleware Setup

// CORS configuration to allow your frontend to communicate with this backend
// Explicitly specify origins for security
app.use(cors({
    origin: 'http://localhost:3000', // **Important:** Replace with your actual frontend URL if different
    credentials: true // Essential for sending cookies (sessions) across origins
}));

// Body parsing middleware to handle incoming request bodies
app.use(bodyParser.json()); // Parses JSON-formatted request bodies
app.use(bodyParser.urlencoded({ extended: true })); // Parses URL-encoded request bodies

// Database connection pool setup
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'Felix300512#', // **Your MySQL password goes here**
    database: 'pssms', // **Ensure this matches your database name**
    waitForConnections: true, // If true, connection requests will wait if none are available
    connectionLimit: 10, 
    queueLimit: 0 
});

// Test connection
pool.query('SELECT 1')
  .then(() => console.log('✅ MySQL Connected'))
  .catch(err => console.error('❌ MySQL Connection Failed:', err));

// Session Store Configuration: Stores user sessions directly in your MySQL database
const sessionStore = new MySQLStore({}, pool);

// Express Session Middleware: Manages user sessions
app.use(session({
    key: 'session_cookie_name', // A unique name for your session cookie
    secret: 'your_super_secret_key_edvin', // **CRITICAL: Replace with a strong, unique, and secret key!**
    store: sessionStore, // Links to the MySQL session store
    resave: false, // Prevents saving the session back to the session store if it wasn't modified
    saveUninitialized: false, // Prevents saving new sessions that have not been modified
    cookie: {
        maxAge: 1000 * 60 * 60 * 24, // Cookie will expire in 24 hours (milliseconds)
        httpOnly: true, // Prevents client-side JavaScript from accessing the cookie
        secure: process.env.NODE_ENV === 'production', // Use secure cookies (HTTPS) in production environments
        sameSite: 'Lax', // Provides CSRF protection by controlling when cookies are sent with cross-site requests
    }
}));

// Authentication Routes

// User registration: Creates a new user in the database
app.post('/api/register', async (req, res) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({ message: 'Username and password are required.' });
        }

        const hashedPassword = await bcrypt.hash(password, 10); // Hash the password for security

        await pool.execute(
            'INSERT INTO users (username, password) VALUES (?, ?)',
            [username, hashedPassword]
        );

        res.status(201).json({ message: 'User registered successfully!' }); // 201 Created status for successful resource creation
    } catch (error) {
        if (error.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({ message: 'Username already exists.' }); // 409 Conflict for duplicate entry
        }
        console.error('Error registering user:', error);
        res.status(500).json({ message: 'Internal server error during registration.' });
    }
});

// User login: Authenticates a user and establishes a session
app.post('/api/login', async (req, res) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({ message: 'Username and password are required.' });
        }

        const [users] = await pool.execute('SELECT * FROM users WHERE username = ?', [username]);

        if (users.length === 0) {
            return res.status(401).json({ message: 'Invalid username or password.' }); // 401 Unauthorized for bad credentials
        }

        const user = users[0];
        const match = await bcrypt.compare(password, user.password); // Compare provided password with hashed password

        if (match) {
            req.session.user = { // Store user info in the session
                id: user.id,
                username: user.username,
                role: user.role // Assuming your 'users' table has a 'role' column
            };
            return res.json({ message: 'Login successful', user: req.session.user });
        }

        res.status(401).json({ message: 'Invalid username or password.' });
    } catch (error) {
        console.error('Error during login:', error);
        res.status(500).json({ message: 'Internal server error during login.' });
    }
});

// User logout: Destroys the current user session
app.post('/api/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            console.error('Error destroying session:', err);
            return res.status(500).json({ message: 'Failed to log out, please try again.' });
        }
        res.clearCookie('session_cookie_name'); // Clear the specific session cookie from the client
        res.json({ message: 'Logged out successfully.' });
    });
});

// Check authentication status: Verifies if a user is currently logged in
app.get('/api/check-auth', (req, res) => {
    if (req.session.user) {
        res.json({ authenticated: true, user: req.session.user });
    } else {
        res.json({ authenticated: false, user: null });
    }
});

// Parking Management (Slots & Vehicles)

// Add new parking slot
app.post('/api/slots', async (req, res) => {
    try {
        const { slotnumber, slotstatus } = req.body;

        if (!slotnumber || !slotstatus) {
            return res.status(400).json({ message: 'Slot number and status are required.' });
        }

        // Check if a slot with this number already exists
        const [existingSlot] = await pool.execute('SELECT * FROM parkingslot WHERE slotnumber = ?', [slotnumber]);
        if (existingSlot.length > 0) {
            return res.status(409).json({ message: 'Slot number already exists.' });
        }

        await pool.execute(
            'INSERT INTO parkingslot (slotnumber, slotstatus) VALUES (?, ?)',
            [slotnumber, slotstatus]
        );

        res.status(201).json({ message: 'Parking slot added successfully!' });
    } catch (error) {
        console.error('Error adding parking slot:', error);
        res.status(500).json({ message: 'Failed to add parking slot.' });
    }
});

// Get all parking slots (with optional status filter)
// This route is already present and correctly structured for your Dashboard.jsx
app.get('/api/slots', async (req, res) => {
    try {
        const { status } = req.query; // Allows filtering by status (e.g., /api/slots?status=available)
        let query = 'SELECT * FROM parkingslot';
        let params = [];

        if (status) {
            query += ' WHERE slotstatus = ?';
            params.push(status);
        }

        const [slots] = await pool.execute(query, params);
        res.json(slots);
    } catch (error) {
        console.error('Error fetching slots:', error);
        res.status(500).json({ message: 'Failed to fetch slots.' });
    }
});

// Update slot status
app.put('/api/slots/:slotnumber', async (req, res) => {
    try {
        const { slotnumber } = req.params;
        const { slotstatus } = req.body; // Expecting 'slotstatus' from frontend

        // Add a console.log here to inspect incoming data
        console.log(`PUT /api/slots/${slotnumber} - Received body:`, req.body);
        console.log(`Attempting to update slot ${slotnumber} to status: ${slotstatus}`);


        if (!slotstatus) {
            // This is the check that causes the 400 if 'slotstatus' is missing from the body
            return res.status(400).json({ message: 'Slot status (slotstatus) is required in the request body.' });
        }

        const [result] = await pool.execute(
            'UPDATE parkingslot SET slotstatus = ? WHERE slotnumber = ?',
            [slotstatus, slotnumber]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Parking slot not found or status already the same.' });
        }

        res.json({ message: 'Parking slot status updated successfully.' });
    } catch (error) {
        console.error('Error updating parking slot:', error);
        res.status(500).json({ message: 'Failed to update parking slot status.' });
    }
});

// Register new vehicle
app.post('/api/vehicles', async (req, res) => {
    try {
        const { plateno, drivername, phonenumber } = req.body;

        if (!plateno || !drivername || !phonenumber) {
            return res.status(400).json({ message: 'All vehicle details (plate number, driver name, phone number) are required.' });
        }

        await pool.execute(
            'INSERT INTO car (plateno, drivername, phonenumber) VALUES (?, ?, ?)',
            [plateno, drivername, phonenumber]
        );

        res.status(201).json({ message: 'Vehicle registered successfully!' });
    } catch (error) {
        if (error.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({ message: 'Vehicle with this plate number is already registered.' });
        }
        console.error('Error registering vehicle:', error);
        res.status(500).json({ message: 'Failed to register vehicle.' });
    }
});

// Get all vehicles
app.get('/api/vehicles', async (req, res) => {
    try {
        const [vehicles] = await pool.execute('SELECT * FROM car');
        res.json(vehicles);
    } catch (error) {
        console.error('Error fetching vehicles:', error);
        res.status(500).json({ message: 'Failed to fetch vehicles.' });
    }
});

// Update vehicle details
app.put('/api/vehicles/:plateno', async (req, res) => {
    try {
        const { plateno } = req.params;
        const { drivername, phonenumber } = req.body;

        if (!drivername || !phonenumber) {
            return res.status(400).json({ message: 'Driver name and phone number are required for update.' });
        }

        const [result] = await pool.execute(
            'UPDATE car SET drivername = ?, phonenumber = ? WHERE plateno = ?',
            [drivername, phonenumber, plateno]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Vehicle not found or no changes were made.' });
        }

        res.json({ message: 'Vehicle updated successfully!' });
    } catch (error) {
        console.error('Error updating vehicle:', error);
        res.status(500).json({ message: 'Failed to update vehicle.' });
    }
});

// Delete a vehicle
app.delete('/api/vehicles/:plateno', async (req, res) => {
    try {
        const { plateno } = req.params;

        const [result] = await pool.execute(
            'DELETE FROM car WHERE plateno = ?',
            [plateno]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Vehicle not found.' });
        }

        res.json({ message: 'Vehicle deleted successfully!' });
    } catch (error) {
        console.error('Error deleting vehicle:', error);
        // Handle MySQL foreign key constraint errors
        if (error.code === 'ER_ROW_IS_REFERENCED_2' || error.errno === 1451) {
            return res.status(409).json({ message: 'Cannot delete vehicle: It has associated parking records or payments. Please delete related records first or update database schema for cascade delete.' });
        }
        res.status(500).json({ message: 'Failed to delete vehicle.' });
    }
});

// Parking Records

// Get all parking records
app.get('/api/records', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM parkingrecord ORDER BY entrytime DESC');
        res.json(rows);
    } catch (error) {
        console.error('Error fetching parking records:', error);
        res.status(500).json({ message: 'Failed to fetch parking records.' });
    }
});

// Create new parking record (vehicle entry into a slot)
app.post('/api/records', async (req, res) => {
    try {
        const { platenumber, slotnumber } = req.body;

        if (!platenumber || !slotnumber) {
            return res.status(400).json({ message: 'Plate number and slot number are required.' });
        }

        // Validate: Check if vehicle exists
        const [vehicles] = await pool.execute('SELECT plateno FROM car WHERE plateno = ?', [platenumber]);
        if (vehicles.length === 0) {
            return res.status(404).json({ message: `Vehicle with plate number '${platenumber}' not found.` });
        }

        // Validate: Check if slot exists and is available
        const [slots] = await pool.execute(
            'SELECT slotstatus FROM parkingslot WHERE slotnumber = ?',
            [slotnumber]
        );

        if (slots.length === 0) {
            return res.status(404).json({ message: `Slot ${slotnumber} not found.` });
        }
        if (slots[0].slotstatus !== 'available') {
            return res.status(409).json({ message: `Slot ${slotnumber} is not available.` });
        }

        // Prevent duplicate active sessions for the same vehicle
        const [activeSessions] = await pool.execute(
            'SELECT * FROM parkingrecord WHERE platenumber = ? AND exittime IS NULL',
            [platenumber]
        );
        if (activeSessions.length > 0) {
            return res.status(409).json({ message: `Vehicle '${platenumber}' is already in an active parking session.` });
        }

        // Start the new parking session
        const [result] = await pool.execute(
            'INSERT INTO parkingrecord (platenumber, slotnumber, entrytime) VALUES (?, ?, NOW())',
            [platenumber, slotnumber]
        );

        // Update the slot status to 'occupied'
        await pool.execute(
            'UPDATE parkingslot SET slotstatus = "occupied" WHERE slotnumber = ?',
            [slotnumber]
        );

        res.status(201).json({ message: 'Parking session started successfully!', recordid: result.insertId });
    } catch (error) {
        console.error('Error starting parking session:', error);
        res.status(500).json({ message: 'Failed to start parking session.' });
    }
});

// End parking session (vehicle exit from a slot)
app.put('/api/records/:recordid/exit', async (req, res) => {
    try {
        const { recordid } = req.params;

        // Retrieve current record details
        const [records] = await pool.execute(
            'SELECT slotnumber, exittime FROM parkingrecord WHERE recordid = ?',
            [recordid]
        );

        if (records.length === 0) {
            return res.status(404).json({ message: 'Parking record not found.' });
        }
        if (records[0].exittime !== null) {
            return res.status(400).json({ message: 'Parking session already ended.' });
        }

        // Update the record with the exit time
        const [updateResult] = await pool.execute(
            'UPDATE parkingrecord SET exittime = NOW() WHERE recordid = ?',
            [recordid]
        );

        if (updateResult.affectedRows === 0) {
            // This case should ideally not be hit if the recordid was found above, but it's a safe fallback
            return res.status(500).json({ message: 'Failed to update record exit time (record not found or no change).' });
        }

        // Update the associated parking slot status to 'available'
        const slotnumber = records[0].slotnumber;
        if (slotnumber) { // Ensure slotnumber is valid before updating
            await pool.execute(
                'UPDATE parkingslot SET slotstatus = "available" WHERE slotnumber = ?',
                [slotnumber]
            );
        } else {
            console.warn(`Warning: Slot number not found for recordid ${recordid}. Slot status not updated.`);
        }

        res.json({ message: 'Parking session ended successfully.' });
    } catch (error) {
        console.error('Error ending parking session:', error);
        res.status(500).json({ message: 'Failed to end parking session.' });
    }
});

// Payments

// Process payment for a parking record
app.post('/api/payments', async (req, res) => {
    try {
        // Expecting only recordid and amountpaid from the frontend
        const { recordid, amountpaid } = req.body;

        if (!recordid || !amountpaid) {
            return res.status(400).json({ message: 'Record ID and amount paid are required.' });
        }
        if (isNaN(parseFloat(amountpaid)) || parseFloat(amountpaid) <= 0) {
            return res.status(400).json({ message: 'Amount paid must be a positive number.' });
        }

        // Get plate number and exit time from the parking record
        const [records] = await pool.execute(
            'SELECT platenumber, exittime FROM parkingrecord WHERE recordid = ?',
            [recordid]
        );

        if (records.length === 0) {
            return res.status(404).json({ message: 'Parking record not found.' });
        }
        if (records[0].exittime === null) {
            return res.status(400).json({ message: 'Cannot process payment for an active parking session. End session first.' });
        }

        const platenumber = records[0].platenumber;

        // Check if a payment for this record already exists to prevent duplicates
        const [existingPayment] = await pool.execute(
            'SELECT * FROM payment WHERE recordid = ?',
            [recordid]
        );
        if (existingPayment.length > 0) {
            return res.status(409).json({ message: 'Payment for this record has already been processed.' });
        }

        // Insert the new payment record into the database
        // The 'payment' table is assumed to have: paymentid, recordid, platenumber, amountpaid, paymentdate
        await pool.execute(
            'INSERT INTO payment (recordid, platenumber, amountpaid, paymentdate) VALUES (?, ?, ?, NOW())',
            [recordid, platenumber, amountpaid]
        );

        res.status(201).json({ message: 'Payment processed successfully!' });
    } catch (error) {
        console.error('Error processing payment:', error);
        res.status(500).json({ message: 'Failed to process payment.' });
    }
});

// NEW: Get all payments - this was missing and causing 404s
app.get('/api/payments', async (req, res) => {
    try {
        const [payments] = await pool.execute('SELECT * FROM payment ORDER BY paymentdate DESC');
        res.json(payments);
    } catch (error) {
        console.error('Error fetching payments:', error);
        res.status(500).json({ message: 'Failed to fetch payments.' });
    }
});

// Reports

// Get daily parking report: Fetches detailed parking and payment data for the current day
app.get('/api/reports/daily', async (req, res) => {
    try {
        const { date } = req.query; // This is the crucial line: it retrieves 'date' from the URL query.

        let query = `
            SELECT
                pr.recordid,
                pr.platenumber,
                c.drivername,
                pr.slotnumber,
                pr.entrytime,
                pr.exittime,
                TIMESTAMPDIFF(MINUTE, pr.entrytime, pr.exittime) AS duration_minutes,
                p.amountpaid,
                p.paymentdate
            FROM parkingrecord pr
            LEFT JOIN car c ON pr.platenumber = c.plateno
            LEFT JOIN payment p ON pr.recordid = p.recordid
        `;
        const params = [];

        if (date) {
            // If a date is provided by the frontend, use it to filter
            query += ` WHERE DATE(pr.entrytime) = ?`; // <-- Using a placeholder here
            params.push(date); // <-- Pushing the date into the params array
        } else {
            // If no date is provided, default to the current date on the MySQL server
            query += ` WHERE DATE(pr.entrytime) = CURDATE()`; // <-- No placeholder needed here
        }

        query += ` ORDER BY pr.entrytime DESC`;

        // This is the line that executes the query.
        // It correctly uses the prepared statement format with 'pool.execute'.
        const [results] = await pool.execute(query, params);

        res.json(results);
    } catch (error) {
        console.error('Error generating daily report:', error);
        res.status(500).json({ message: 'Failed to generate daily report.' });
    }
});

// Server Start

// Catch-all for any undefined API routes
app.use((req, res) => {
    res.status(404).send('API endpoint not found.');
});

const PORT = 5000; // The port your backend server will listen on
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});