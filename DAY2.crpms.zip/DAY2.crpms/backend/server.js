const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bcrypt = require('bcryptjs'); // Assuming you're using this for login, keep it.

const app = express();
app.use(cors());
app.use(express.json());

// Database connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root', // replace with your MySQL username
    password: 'Felix300512#', // replace with your MySQL password
    database: 'CRPMS'
});

db.connect(err => {
    if (err) {
        console.error('Database connection failed:', err.stack);
        return;
    }
    console.log('Connected to database.');
});

// Simple user database (for demonstration only)
const users = [
    {
        id: 1,
        username: 'admin',
        // Password is "1234" hashed (ensure this hash is correct for "1234")
        password: '$2a$10$V6rSUrJZq.ZKGDZ1NoI8b.8v8nN9zYTUvD.7Z7QJz5J5z5X5X5X5X'
    }
];

// Login endpoint
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const user = users.find(u => u.username === username);

    if (!user) {
        return res.status(401).send('Invalid username or password');
    }

    // It's generally better to use bcrypt.compare for hashed passwords.
    // For now, I'm keeping your direct "1234" check, but strongly recommend bcrypt.compare.
    // const isMatch = bcrypt.compareSync(password, user.password); // Recommended
    if (password !== "1234") { // Your current logic
        return res.status(401).send('Invalid username or password');
    }
    res.json({ message: 'Login successful', user: { id: user.id, username: user.username } });
});

// CARS endpoints
app.post('/cars', (req, res) => {
    const { PlateNumber, Type, Model, ManufacturingYear, DriverPhone, MechanicName } = req.body;
    const query = 'INSERT INTO Car (PlateNumber, Type, Model, ManufacturingYear, DriverPhone, MechanicName) VALUES (?, ?, ?, ?, ?, ?)';
    db.query(query, [PlateNumber, Type, Model, ManufacturingYear, DriverPhone, MechanicName], (err, result) => {
        if (err) {
            console.error("Car Add Error:", err);
            return res.status(500).json({ message: "Error adding car", error: err.message });
        }
        res.status(201).send('Car added successfully');
    });
});

app.get('/cars', (req, res) => {
    db.query('SELECT * FROM Car', (err, results) => {
        if (err) {
            console.error("Car Fetch Error:", err);
            return res.status(500).json({ message: "Error fetching cars", error: err.message });
        }
        res.json(results);
    });
});

// New: Update Car
app.put('/cars/:plateNumber', (req, res) => {
    const { plateNumber } = req.params;
    const { Type, Model, ManufacturingYear, DriverPhone, MechanicName } = req.body;
    const query = `
        UPDATE Car
        SET Type = ?, Model = ?, ManufacturingYear = ?, DriverPhone = ?, MechanicName = ?
        WHERE PlateNumber = ?
    `;
    db.query(query, [Type, Model, ManufacturingYear, DriverPhone, MechanicName, plateNumber], (err, result) => {
        if (err) {
            console.error("Car Update Error:", err);
            return res.status(500).json({ message: "Error updating car", error: err.message });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Car not found or no changes made." });
        }
        res.send('Car updated successfully');
    });
});

// New: Delete Car
app.delete('/cars/:plateNumber', (req, res) => {
    const { plateNumber } = req.params;
    const query = 'DELETE FROM Car WHERE PlateNumber = ?';
    db.query(query, [plateNumber], (err, result) => {
        if (err) {
            console.error("Car Delete Error:", err);
            return res.status(500).json({ message: "Error deleting car", error: err.message });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Car not found." });
        }
        res.send('Car deleted successfully');
    });
});


// SERVICES endpoints (Existing, keeping for context)
app.get('/services', (req, res) => {
    db.query('SELECT * FROM Services', (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

// SERVICE RECORD endpoints (Existing, keeping for context)
app.post('/service-records', (req, res) => {
    const { ServiceDate, PlateNumber, ServiceCode } = req.body;
    const query = 'INSERT INTO ServiceRecord SET ?';
    db.query(query, { ServiceDate, PlateNumber, ServiceCode }, (err, result) => {
        if (err) return res.status(500).send(err);
        res.status(201).send('Service record added successfully');
    });
});

app.get('/service-records', (req, res) => {
    const query = `
        SELECT sr.RecordNumber, sr.ServiceDate, c.PlateNumber, c.Type, c.Model,
               s.ServiceName, s.ServicePrice
        FROM ServiceRecord sr
        JOIN Car c ON sr.PlateNumber = c.PlateNumber
        JOIN Services s ON sr.ServiceCode = s.ServiceCode
    `;
    db.query(query, (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

// PAYMENT endpoints (Existing, keeping for context)
app.post('/payments', (req, res) => {
    const { AmountPaid, PaymentDate, RecordNumber } = req.body;
    const query = 'INSERT INTO Payment SET ?';
    db.query(query, { AmountPaid, PaymentDate, RecordNumber }, (err, result) => {
        if (err) {
            console.error("Payment Insert Error:", err);
            return res.status(500).send(err);
        }
        res.status(201).send('Payment added successfully');
    });
});


app.get('/payments', (req, res) => {
    const query = `
        SELECT p.PaymentNumber, p.AmountPaid, p.PaymentDate,
               sr.RecordNumber, sr.ServiceDate, c.PlateNumber, c.Model,
               s.ServiceName, s.ServicePrice
        FROM Payment p
        JOIN ServiceRecord sr ON p.RecordNumber = sr.RecordNumber
        JOIN Car c ON sr.PlateNumber = c.PlateNumber
        JOIN Services s ON sr.ServiceCode = s.ServiceCode
    `;
    db.query(query, (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

// REPORTS (Existing, keeping for context)
app.get('/reports/summary', (req, res) => {
    const query = `
        SELECT
            COUNT(DISTINCT p.PaymentNumber) as totalPayments,
            SUM(p.AmountPaid) as totalRevenue,
            COUNT(DISTINCT c.PlateNumber) as totalCarsServiced,
            COUNT(DISTINCT sr.RecordNumber) as totalServices
        FROM Payment p
        JOIN ServiceRecord sr ON p.RecordNumber = sr.RecordNumber
        JOIN Car c ON sr.PlateNumber = c.PlateNumber
    `;
    db.query(query, (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results[0]);
    });
});

// Update service record (Existing, keeping for context)
app.put('/service-records/:id', (req, res) => {
    const { id } = req.params;
    const { ServiceDate, PlateNumber, ServiceCode } = req.body;
    const query = 'UPDATE ServiceRecord SET ServiceDate = ?, PlateNumber = ?, ServiceCode = ? WHERE RecordNumber = ?';
    db.query(query, [ServiceDate, PlateNumber, ServiceCode, id], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send('Service record updated successfully');
    });
});

// Delete service record (Existing, keeping for context)
app.delete('/service-records/:id', (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM ServiceRecord WHERE RecordNumber = ?';
    db.query(query, [id], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send('Service record deleted successfully');
    });
});

// Update payment (Existing, keeping for context)
app.put('/payments/:id', (req, res) => {
    const { id } = req.params;
    const { AmountPaid, PaymentDate, RecordNumber } = req.body;
    const query = 'UPDATE Payment SET AmountPaid = ?, PaymentDate = ?, RecordNumber = ? WHERE PaymentNumber = ?';
    db.query(query, [AmountPaid, PaymentDate, RecordNumber, id], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send('Payment updated successfully');
    });
});

// Delete payment (Existing, keeping for context)
app.delete('/payments/:id', (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM Payment WHERE PaymentNumber = ?';
    db.query(query, [id], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send('Payment deleted successfully');
    });
});

const PORT = 5000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});