import { useState, useEffect } from 'react';
import axios from 'axios';

const Cars = () => {
    const [cars, setCars] = useState([]);
    const [formData, setFormData] = useState({
        PlateNumber: '',
        Type: '',
        Model: '',
        ManufacturingYear: '',
        DriverPhone: '',
        MechanicName: ''
    });
    const [editingCar, setEditingCar] = useState(null); // State to hold car being edited

    useEffect(() => {
        fetchCars();
    }, []);

    const fetchCars = async () => {
        try {
            const res = await axios.get('http://localhost:5000/cars');
            setCars(res.data);
        } catch (err) {
            console.error('Error fetching cars:', err);
        }
    };

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (editingCar) {
                // Update existing car
                await axios.put(`http://localhost:5000/cars/${editingCar.PlateNumber}`, formData);
                setEditingCar(null); // Clear editing state
            } else {
                // Add new car
                await axios.post('http://localhost:5000/cars', formData);
            }
            fetchCars(); // Refresh list
            setFormData({ // Reset form
                PlateNumber: '',
                Type: '',
                Model: '',
                ManufacturingYear: '',
                DriverPhone: '',
                MechanicName: ''
            });
        } catch (err) {
            console.error('Error submitting car data:', err);
        }
    };

    const handleEdit = (car) => {
        setEditingCar(car);
        setFormData({ ...car }); // Populate form with car data
    };

    const handleDelete = async (plateNumber) => {
        if (window.confirm(`Are you sure you want to delete car with Plate Number: ${plateNumber}?`)) {
            try {
                await axios.delete(`http://localhost:5000/cars/${plateNumber}`);
                fetchCars(); // Refresh list
            } catch (err) {
                console.error('Error deleting car:', err);
            }
        }
    };

    const handleCancelEdit = () => {
        setEditingCar(null);
        setFormData({ // Reset form
            PlateNumber: '',
            Type: '',
            Model: '',
            ManufacturingYear: '',
            DriverPhone: '',
            MechanicName: ''
        });
    };

    return (
        <div className="container mx-auto p-4">
            <h2 className="text-3xl font-bold mb-6 text-gray-800">Cars Management</h2>

            <form onSubmit={handleSubmit} className="mb-8 bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-2xl font-semibold mb-4 text-gray-700">
                    {editingCar ? 'Edit Car' : 'Add New Car'}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
                    <div>
                        <label htmlFor="PlateNumber" className="block text-sm font-medium text-gray-700 mb-1">Plate Number</label>
                        <input
                            type="text"
                            name="PlateNumber"
                            id="PlateNumber"
                            value={formData.PlateNumber}
                            onChange={handleChange}
                            className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                            required
                            readOnly={!!editingCar} // Make PlateNumber read-only when editing
                        />
                         {editingCar && (
                            <p className="text-sm text-gray-500 mt-1">Plate Number cannot be changed during edit.</p>
                        )}
                    </div>
                    <div>
                        <label htmlFor="Type" className="block text-sm font-medium text-gray-700 mb-1">Type</label>
                        <input
                            type="text"
                            name="Type"
                            id="Type"
                            value={formData.Type}
                            onChange={handleChange}
                            className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                            required
                        />
                    </div>
                    <div>
                        <label htmlFor="Model" className="block text-sm font-medium text-gray-700 mb-1">Model</label>
                        <input
                            type="text"
                            name="Model"
                            id="Model"
                            value={formData.Model}
                            onChange={handleChange}
                            className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                            required
                        />
                    </div>
                    <div>
                        <label htmlFor="ManufacturingYear" className="block text-sm font-medium text-gray-700 mb-1">Manufacturing Year</label>
                        <input
                            type="number"
                            name="ManufacturingYear"
                            id="ManufacturingYear"
                            value={formData.ManufacturingYear}
                            onChange={handleChange}
                            className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                            required
                        />
                    </div>
                    <div>
                        <label htmlFor="DriverPhone" className="block text-sm font-medium text-gray-700 mb-1">Driver Phone</label>
                        <input
                            type="text"
                            name="DriverPhone"
                            id="DriverPhone"
                            value={formData.DriverPhone}
                            onChange={handleChange}
                            className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                            required
                        />
                    </div>
                    <div>
                        <label htmlFor="MechanicName" className="block text-sm font-medium text-gray-700 mb-1">Mechanic Name</label>
                        <input
                            type="text"
                            name="MechanicName"
                            id="MechanicName"
                            value={formData.MechanicName}
                            onChange={handleChange}
                            className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                            required
                        />
                    </div>
                </div>
                <div className="flex space-x-2">
                    <button
                        type="submit"
                        className="bg-blue-600 text-white px-5 py-2 rounded-md hover:bg-blue-700 transition duration-300 ease-in-out shadow-md"
                    >
                        {editingCar ? 'Update Car' : 'Add Car'}
                    </button>
                    {editingCar && (
                        <button
                            type="button"
                            onClick={handleCancelEdit}
                            className="bg-gray-500 text-white px-5 py-2 rounded-md hover:bg-gray-600 transition duration-300 ease-in-out shadow-md"
                        >
                            Cancel
                        </button>
                    )}
                </div>
            </form>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <h3 className="text-2xl font-semibold p-4 bg-gray-100 text-gray-700">Car List</h3>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Plate Number</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Model</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Year</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Driver Phone</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Mechanic</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {cars.length === 0 ? (
                                <tr>
                                    <td colSpan="7" className="px-6 py-4 text-center text-gray-500">No cars found.</td>
                                </tr>
                            ) : (
                                cars.map((car) => (
                                    <tr key={car.PlateNumber}>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{car.PlateNumber}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{car.Type}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{car.Model}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{car.ManufacturingYear}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{car.DriverPhone}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{car.MechanicName}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                            <button
                                                onClick={() => handleEdit(car)}
                                                className="text-indigo-600 hover:text-indigo-900 mr-4"
                                            >
                                                Edit
                                            </button>
                                            <button
                                                onClick={() => handleDelete(car.PlateNumber)}
                                                className="text-red-600 hover:text-red-900"
                                            >
                                                Delete
                                            </button>
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Cars;