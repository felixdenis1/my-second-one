// Home.js
import { Link } from 'react-router-dom';

const Home = ({ handleLogout }) => {
    return (
        <div className="min-h-screen bg-gray-100">
            <nav className="bg-blue-600 text-white p-4">
                <div className="container mx-auto flex justify-between items-center">
                    <h1 className="text-xl font-bold">CRPMS</h1>
                    <div className="flex space-x-4">
                        <Link to="/" className="hover:bg-blue-700 px-3 py-2 rounded">Home</Link>
                        <Link to="/cars" className="hover:bg-blue-700 px-3 py-2 rounded">Cars</Link>
                        <Link to="/services" className="hover:bg-blue-700 px-3 py-2 rounded">Services</Link>
                        <Link to="/service-records" className="hover:bg-blue-700 px-3 py-2 rounded">Service Records</Link>
                        <Link to="/payments" className="hover:bg-blue-700 px-3 py-2 rounded">Payments</Link>
                        <Link to="/reports" className="hover:bg-blue-700 px-3 py-2 rounded">Reports</Link>
                        <button 
                            onClick={handleLogout}
                            className="hover:bg-blue-700 px-3 py-2 rounded"
                        >
                            Logout
                        </button>
                    </div>
                </div>
            </nav>

            <div className="container mx-auto p-4">
                {/* ... rest of your home page content ... */}
            </div>

<div class="flex items-center justify-center min-h-screen bg-gray-900">
  <p class="text-5xl font-extrabold text-white text-center tracking-wide leading-tight animate-fade-in-up drop-shadow-lg">
    WELCOME TO CAR'S MANAGEMENT service
  </p>
</div>


        </div>
    );
};

export default Home;