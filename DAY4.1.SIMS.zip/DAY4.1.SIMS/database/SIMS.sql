CREATE DATABASE SIMS;

USE SIMS;

CREATE TABLE Spare_Part (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(255) NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    total_price DECIMAL(10, 2) NOT NULL
);

CREATE TABLE Stock_In (
    id INT AUTO_INCREMENT PRIMARY KEY,
    spare_part_id INT NOT NULL,
    stock_in_quantity INT NOT NULL,
    stock_in_date DATE NOT NULL,
    FOREIGN KEY (spare_part_id) REFERENCES Spare_Part(id)
);

CREATE TABLE Stock_Out (
    id INT AUTO_INCREMENT PRIMARY KEY,
    spare_part_id INT NOT NULL,
    stock_out_quantity INT NOT NULL,
    stock_out_unit_price DECIMAL(10, 2) NOT NULL,
    stock_out_total_price DECIMAL(10, 2) NOT NULL,
    stock_out_date DATE NOT NULL,
    FOREIGN KEY (spare_part_id) REFERENCES Spare_Part(id)
);