import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './Login';

function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Check if user is logged in on initial load
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const storedUser = localStorage.getItem('user');
        if (storedUser) {
          setUser(JSON.parse(storedUser));
        }
      } catch (error) {
        console.error('Auth check failed:', error);
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('user');
    setUser(null);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <Router>
      <Routes>
        <Route 
          path="/login" 
          element={user ? <Navigate to="/" /> : <Login setUser={setUser} />} 
        />
        <Route 
          path="/" 
          element={
            user ? (
              <InventoryDashboard user={user} onLogout={handleLogout} />
            ) : (
              <Navigate to="/login" />
            )
          } 
        />
      </Routes>
    </Router>
  );
}

function InventoryDashboard({ user, onLogout }) {
  const [activeTab, setActiveTab] = useState('spare-parts');
  const [spareParts, setSpareParts] = useState([]);
  const [stockIns, setStockIns] = useState([]);
  const [stockOuts, setStockOuts] = useState([]);
  const [editingPart, setEditingPart] = useState(null);
  const [editingStockIn, setEditingStockIn] = useState(null);
  const [editingStockOut, setEditingStockOut] = useState(null);
  const [newPart, setNewPart] = useState({ name: '', category: '', quantity: '', unit_price: '' });
  const [newStockIn, setNewStockIn] = useState({ partId: '', quantity: '' });
  const [newStockOut, setNewStockOut] = useState({ partId: '', quantity: '', unit_price: '' });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [partsRes, insRes, outsRes] = await Promise.all([
        axios.get('http://localhost:5000/spare-parts'),
        axios.get('http://localhost:5000/stock-in'),
        axios.get('http://localhost:5000/stock-out')
      ]);
      
      setSpareParts(partsRes.data);
      setStockIns(insRes.data);
      setStockOuts(outsRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
      alert('Failed to fetch data. Please check console for details.');
    }
  };

  const formatPrice = (price) => {
    const num = Number(price);
    return isNaN(num) ? '$0.00' : `$${num.toFixed(2)}`;
  };

  const handleAddPart = async () => {
    try {
      const response = await axios.post('http://localhost:5000/spare-parts', {
        name: newPart.name,
        category: newPart.category,
        quantity: newPart.quantity,
        unit_Price: newPart.unit_price
      });
      fetchData();
      setNewPart({ name: '', category: '', quantity: '', unit_price: '' });
    } catch (error) {
      console.error('Error adding part:', error);
      const errorMessage = error.response?.data?.error || 
                         error.response?.data?.sqlMessage || 
                         error.message;
      alert(`Failed to add part: ${errorMessage}`);
    }
  };

  const handleStockIn = async () => {
    try {
      await axios.post('http://localhost:5000/stock-in', newStockIn);
      fetchData();
      setNewStockIn({ partId: '', quantity: 0 });
    } catch (error) {
      console.error('Error adding stock in:', error);
      alert(`Failed to add stock in: ${error.response?.data?.error || error.message}`);
    }
  };

  const handleStockOut = async () => {
    try {
      await axios.post('http://localhost:5000/stock-out', {
        ...newStockOut,
        total_price: newStockOut.quantity * Number(newStockOut.unit_price)
      });
      fetchData();
      setNewStockOut({ partId: '', quantity: '', unit_price: '' });
    } catch (error) {
      console.error('Error adding stock out:', error);
      alert(`Failed to add stock out: ${error.response?.data?.error || error.message}`);
    }
  };

  const handleUpdatePart = async () => {
    if (!editingPart) return;
    
    try {
      const response = await axios.put(
        `http://localhost:5000/spare-parts/${editingPart.id}`,
        {
          name: editingPart.name,
          category: editingPart.category,
          quantity: editingPart.quantity,
          unit_price: editingPart.unit_price
        },
        {
          headers: {
            'Content-Type': 'application/json'
          }
        }
      );

      if (response.status === 200) {
        fetchData();
        setEditingPart(null);
        alert('Part updated successfully!');
      } else {
        throw new Error(response.data.message || 'Failed to update part');
      }
    } catch (error) {
      console.error('Error updating part:', error);
      console.log('Error details:', error.response?.data);
      alert(`Failed to update part: ${error.response?.data?.message || error.response?.data?.error || error.message}`);
    }
  };

  const handleDeletePart = async (partId) => {
    if (!window.confirm('Are you sure you want to delete this part?')) return;
    
    try {
      await axios.delete(`http://localhost:5000/spare-parts/${partId}`);
      fetchData();
    } catch (error) {
      console.error('Error deleting part:', error);
      alert(`Failed to delete part: ${error.response?.data?.error || error.message}`);
    }
  };

  const handleUpdateStockIn = async (stockInId, updatedData) => {
    try {
      await axios.put(`http://localhost:5000/stock-in/${stockInId}`, updatedData);
      fetchData();
      setEditingStockIn(null);
    } catch (error) {
      console.error('Error updating stock in:', error);
      alert(`Failed to update stock in: ${error.response?.data?.error || error.message}`);
    }
  };

  const handleDeleteStockIn = async (stockInId) => {
    if (!window.confirm('Are you sure you want to delete this stock in record?')) return;
    
    try {
      await axios.delete(`http://localhost:5000/stock-in/${stockInId}`);
      fetchData();
    } catch (error) {
      console.error('Error deleting stock in:', error);
      alert(`Failed to delete stock in: ${error.response?.data?.error || error.message}`);
    }
  };

  const handleUpdateStockOut = async (stockOutId, updatedData) => {
    try {
      await axios.put(`http://localhost:5000/stock-out/${stockOutId}`, updatedData);
      fetchData();
      setEditingStockOut(null);
    } catch (error) {
      console.error('Error updating stock out:', error);
      alert(`Failed to update stock out: ${error.response?.data?.error || error.message}`);
    }
  };

  const handleDeleteStockOut = async (stockOutId) => {
    if (!window.confirm('Are you sure you want to delete this stock out record?')) return;
    
    try {
      await axios.delete(`http://localhost:5000/stock-out/${stockOutId}`);
      fetchData();
    } catch (error) {
      console.error('Error deleting stock out:', error);
      alert(`Failed to delete stock out: ${error.response?.data?.error || error.message}`);
    }
  };

  return (
    <div className="container mx-auto p-4">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Stock Inventory Management</h1>
        <div className="flex items-center">
          <span className="mr-2">Welcome, {user.username}</span>
          <button 
            onClick={onLogout}
            className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded transition duration-200"
          >
            Logout
          </button>
        </div>
      </div>
      
      <div className="flex mb-4">
        <button 
          className={`px-4 py-2 mr-2 rounded ${activeTab === 'spare-parts' ? 'bg-blue-500 text-white' : 'bg-gray-200 hover:bg-gray-300'}`}
          onClick={() => setActiveTab('spare-parts')}
        >
          Spare Parts
        </button>
        <button 
          className={`px-4 py-2 mr-2 rounded ${activeTab === 'stock-in' ? 'bg-blue-500 text-white' : 'bg-gray-200 hover:bg-gray-300'}`}
          onClick={() => setActiveTab('stock-in')}
        >
          Stock In
        </button>
        <button 
          className={`px-4 py-2 mr-2 rounded ${activeTab === 'stock-out' ? 'bg-blue-500 text-white' : 'bg-gray-200 hover:bg-gray-300'}`}
          onClick={() => setActiveTab('stock-out')}
        >
          Stock Out
        </button>
        <button 
          className={`px-4 py-2 rounded ${activeTab === 'reports' ? 'bg-blue-500 text-white' : 'bg-gray-200 hover:bg-gray-300'}`}
          onClick={() => setActiveTab('reports')}
        >
          Reports
        </button>
      </div>
      
      {activeTab === 'spare-parts' && (
        <div>
          <h2 className="text-xl font-semibold mb-2">Add New Spare Part</h2>
          <div className="mb-4 grid grid-cols-1 md:grid-cols-5 gap-2">
            <input
              type="text"
              placeholder="Name"
              value={newPart.name}
              onChange={(e) => setNewPart({...newPart, name: e.target.value})}
              className="border p-2 rounded"
            />
            <input
              type="text"
              placeholder="Category"
              value={newPart.category}
              onChange={(e) => setNewPart({...newPart, category: e.target.value})}
              className="border p-2 rounded"
            />
            <input
              type="number"
              placeholder="Quantity"
              value={newPart.quantity}
              onChange={(e) => setNewPart({...newPart, quantity: parseInt(e.target.value) || 0})}
              className="border p-2 rounded"
              min="0"
            />
            <input
              type="number"
              placeholder="Unit Price"
              value={newPart.unit_price}
              onChange={(e) => setNewPart({...newPart, unit_price: parseFloat(e.target.value) || 0})}
              className="border p-2 rounded"
              step="0.01"
              min="0"
            />
            <button 
              onClick={handleAddPart} 
              className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded disabled:opacity-50"
              disabled={!newPart.name || !newPart.category || newPart.quantity <= 0}
            >
              Add Part
            </button>
          </div>
          
          {/* Edit Part Modal */}
          {editingPart && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
              <div className="bg-white p-6 rounded-lg max-w-md w-full">
                <h2 className="text-xl font-semibold mb-4">Edit Spare Part</h2>
                <div className="grid grid-cols-1 gap-4 mb-4">
                  <input
                    type="text"
                    placeholder="Name"
                    value={editingPart.name}
                    onChange={(e) => setEditingPart({...editingPart, name: e.target.value})}
                    className="border p-2 rounded"
                  />
                  <input
                    type="text"
                    placeholder="Category"
                    value={editingPart.category}
                    onChange={(e) => setEditingPart({...editingPart, category: e.target.value})}
                    className="border p-2 rounded"
                  />
                  <input
                    type="number"
                    placeholder="Quantity"
                    value={editingPart.quantity}
                    onChange={(e) => setEditingPart({...editingPart, quantity: parseInt(e.target.value) || 0})}
                    className="border p-2 rounded"
                    min="0"
                  />
                  <input
                    type="number"
                    placeholder="Unit Price"
                    value={editingPart.unit_price}
                    onChange={(e) => setEditingPart({...editingPart, unit_price: parseFloat(e.target.value) || 0})}
                    className="border p-2 rounded"
                    step="0.01"
                    min="0"
                  />
                </div>
                <div className="flex justify-end space-x-2">
                  <button
                    onClick={() => setEditingPart(null)}
                    className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleUpdatePart}
                    className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded"
                  >
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          )}

          <h2 className="text-xl font-semibold mb-2">Spare Parts List</h2>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border p-2 text-left">Name</th>
                  <th className="border p-2 text-left">Category</th>
                  <th className="border p-2 text-left">Quantity</th>
                  <th className="border p-2 text-left">Unit Price</th>
                  <th className="border p-2 text-left">Total Price</th>
                  <th className="border p-2 text-left">Actions</th>
                </tr>
              </thead>
              <tbody>
                {spareParts.map(part => (
                  <tr key={part.id} className="hover:bg-gray-50">
                    <td className="border p-2">{part.name}</td>
                    <td className="border p-2">{part.category}</td>
                    <td className="border p-2">{part.quantity}</td>
                    <td className="border p-2">{formatPrice(part.unit_price)}</td>
                    <td className="border p-2">{formatPrice(part.total_price || part.quantity * part.unit_price)}</td>
                    <td className="border p-2 flex space-x-2">
                      <button
                        onClick={() => setEditingPart(part)}
                        className="bg-blue-500 hover:bg-blue-600 text-white px-2 py-1 rounded"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDeletePart(part.id)}
                        className="bg-red-500 hover:bg-red-600 text-white px-2 py-1 rounded"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      
      {activeTab === 'stock-in' && (
        <div>
          <h2 className="text-xl font-semibold mb-2">Stock In</h2>
          <div className="mb-4 grid grid-cols-1 md:grid-cols-3 gap-2">
            <select
              value={newStockIn.partId}
              onChange={(e) => setNewStockIn({...newStockIn, partId: e.target.value})}
              className="border p-2 rounded"
            >
              <option value="">Select Part</option>
              {spareParts.map(part => (
                <option key={part.id} value={part.id}>{part.name} (Current: {part.quantity})</option>
              ))}
            </select>
            <input
              type="number"
              placeholder="Quantity"
              value={newStockIn.quantity}
              onChange={(e) => setNewStockIn({...newStockIn, quantity: parseInt(e.target.value) || 0})}
              className="border p-2 rounded"
              min="1"
            />
            <button 
              onClick={handleStockIn} 
              className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded disabled:opacity-50"
              disabled={!newStockIn.partId || newStockIn.quantity <= 0}
            >
              Add Stock In
            </button>
          </div>

          {/* Edit Stock In Modal */}
          {editingStockIn && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
              <div className="bg-white p-6 rounded-lg max-w-md w-full">
                <h2 className="text-xl font-semibold mb-4">Edit Stock In</h2>
                <div className="grid grid-cols-1 gap-4 mb-4">
                  <select
                    value={editingStockIn.spare_part_id}
                    onChange={(e) => setEditingStockIn({...editingStockIn, spare_part_id: e.target.value})}
                    className="border p-2 rounded"
                  >
                    <option value="">Select Part</option>
                    {spareParts.map(part => (
                      <option key={part.id} value={part.id}>{part.name}</option>
                    ))}
                  </select>
                  <input
                    type="number"
                    placeholder="Quantity"
                    value={editingStockIn.stock_in_quantity}
                    onChange={(e) => setEditingStockIn({...editingStockIn, stock_in_quantity: parseInt(e.target.value) || 0})}
                    className="border p-2 rounded"
                    min="1"
                  />
                </div>
                <div className="flex justify-end space-x-2">
                  <button
                    onClick={() => setEditingStockIn(null)}
                    className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      handleUpdateStockIn(editingStockIn.id, {
                        spare_part_id: editingStockIn.spare_part_id,
                        stock_in_quantity: editingStockIn.stock_in_quantity
                      });
                    }}
                    className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded"
                  >
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          )}

          <h2 className="text-xl font-semibold mb-2">Stock In History</h2>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border p-2 text-left">Part Name</th>
                  <th className="border p-2 text-left">Quantity</th>
                  <th className="border p-2 text-left">Date</th>
                  <th className="border p-2 text-left">Actions</th>
                </tr>
              </thead>
              <tbody>
                {stockIns.map(stock => (
                  <tr key={stock.id} className="hover:bg-gray-50">
                    <td className="border p-2">{stock.part_name || `Part ID: ${stock.spare_part_id}`}</td>
                    <td className="border p-2">{stock.stock_in_quantity}</td>
                    <td className="border p-2">{new Date(stock.stock_in_date).toLocaleString()}</td>
                    <td className="border p-2 flex space-x-2">
                      <button
                        onClick={() => setEditingStockIn(stock)}
                        className="bg-blue-500 hover:bg-blue-600 text-white px-2 py-1 rounded"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDeleteStockIn(stock.id)}
                        className="bg-red-500 hover:bg-red-600 text-white px-2 py-1 rounded"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      
      {activeTab === 'stock-out' && (
        <div>
          <h2 className="text-xl font-semibold mb-2">Stock Out</h2>
          <div className="mb-4 grid grid-cols-1 md:grid-cols-4 gap-2">
            <select
              value={newStockOut.partId}
              onChange={(e) => setNewStockOut({...newStockOut, partId: e.target.value})}
              className="border p-2 rounded"
            >
              <option value="">Select Part</option>
              {spareParts.map(part => (
                <option key={part.id} value={part.id}>{part.name} (Current: {part.quantity})</option>
              ))}
            </select>
            <input
              type="number"
              placeholder="Quantity"
              value={newStockOut.quantity}
              onChange={(e) => setNewStockOut({...newStockOut, quantity: parseInt(e.target.value) || 0})}
              className="border p-2 rounded"
              min="1"
            />
            <input
              type="number"
              placeholder="Unit Price"
              value={newStockOut.unit_price}
              onChange={(e) => setNewStockOut({...newStockOut, unit_price: parseFloat(e.target.value) || 0})}
              className="border p-2 rounded"
              min="0"
              step="0.01"
            />
            <button 
              onClick={handleStockOut} 
              className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded disabled:opacity-50"
              disabled={!newStockOut.partId || newStockOut.quantity <= 0 || newStockOut.unit_price <= 0}
            >
              Add Stock Out
            </button>
          </div>

          {/* Edit Stock Out Modal */}
          {editingStockOut && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
              <div className="bg-white p-6 rounded-lg max-w-md w-full">
                <h2 className="text-xl font-semibold mb-4">Edit Stock Out</h2>
                <div className="grid grid-cols-1 gap-4 mb-4">
                  <select
                    value={editingStockOut.partId}
                    onChange={(e) => setEditingStockOut({...editingStockOut, partId: e.target.value})}
                    className="border p-2 rounded"
                  >
                    <option value="">Select Part</option>
                    {spareParts.map(part => (
                      <option key={part.id} value={part.id}>{part.name}</option>
                    ))}
                  </select>
                  <input
                    type="number"
                    placeholder="Quantity"
                    value={editingStockOut.quantity}
                    onChange={(e) => setEditingStockOut({...editingStockOut, quantity: parseInt(e.target.value) || 0})}
                    className="border p-2 rounded"
                    min="1"
                  />
                  <input
                    type="number"
                    placeholder="Unit Price"
                    value={editingStockOut.unit_price}
                    onChange={(e) => setEditingStockOut({...editingStockOut, unit_price: parseFloat(e.target.value) || 0})}
                    className="border p-2 rounded"
                    min="0"
                    step="0.01"
                  />
                </div>
                <div className="flex justify-end space-x-2">
                  <button
                    onClick={() => setEditingStockOut(null)}
                    className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      handleUpdateStockOut(editingStockOut.id, {
                        partId: editingStockOut.partId,
                        quantity: editingStockOut.quantity,
                        unit_price: editingStockOut.unit_price,
                        total_price: editingStockOut.quantity * editingStockOut.unit_price
                      });
                    }}
                    className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded"
                  >
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          )}

          <h2 className="text-xl font-semibold mb-2">Stock Out History</h2>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border p-2 text-left">Part Name</th>
                  <th className="border p-2 text-left">Quantity</th>
                  <th className="border p-2 text-left">Unit Price</th>
                  <th className="border p-2 text-left">Total Price</th>
                  <th className="border p-2 text-left">Date</th>
                  <th className="border p-2 text-left">Actions</th>
                </tr>
              </thead>
              <tbody>
                {stockOuts.map(stock => {
                  const part = spareParts.find(p => p.id === stock.partId);
                  return (
                    <tr key={stock.id} className="hover:bg-gray-50">
                      <td className="border p-2">{part ? part.name : `Part ID: ${stock.partId}`}</td>
                      <td className="border p-2">{stock.quantity}</td>
                      <td className="border p-2">{formatPrice(stock.unit_price)}</td>
                      <td className="border p-2">{formatPrice(stock.total_price || stock.quantity * stock.unit_price)}</td>
                      <td className="border p-2">{new Date(stock.date).toLocaleString()}</td>
                      <td className="border p-2 flex space-x-2">
                        <button
                          onClick={() => setEditingStockOut(stock)}
                          className="bg-blue-500 hover:bg-blue-600 text-white px-2 py-1 rounded"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => handleDeleteStockOut(stock.id)}
                          className="bg-red-500 hover:bg-red-600 text-white px-2 py-1 rounded"
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
      
      {activeTab === 'reports' && (
        <div>
          <h2 className="text-xl font-semibold mb-2">Stock Status Report</h2>
          <button 
            onClick={fetchData}
            className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded mb-4"
          >
            Refresh Report
          </button>
          
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border p-2 text-left">Spare Part</th>
                  <th className="border p-2 text-left">Current Quantity</th>
                  <th className="border p-2 text-left">Total In</th>
                  <th className="border p-2 text-left">Total Out</th>
                </tr>
              </thead>
              <tbody>
                {spareParts.map(part => {
                  const totalIn = stockIns
                    .filter(inItem => inItem.spare_part_id === part.id)
                    .reduce((sum, inItem) => sum + inItem.stock_in_quantity, 0);
                  
                  const totalOut = stockOuts
                    .filter(out => out.partId === part.id)
                    .reduce((sum, out) => sum + out.quantity, 0);
                  
                  return (
                    <tr key={part.id} className="hover:bg-gray-50">
                      <td className="border p-2">{part.name}</td>
                      <td className="border p-2">{part.quantity}</td>
                      <td className="border p-2">{totalIn}</td>
                      <td className="border p-2">{totalOut}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;