const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mysql = require('mysql2/promise');

const app = express();
app.use(cors({
  origin: 'http://localhost:3000',
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  credentials: true
}));
app.use(bodyParser.json());

// MySQL Database Connection
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'Felix300512#',
  database: 'SIMS',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Test connection
pool.query('SELECT 1')
  .then(() => console.log('✅ MySQL Connected'))
  .catch(err => console.error('❌ MySQL Connection Failed:', err));
const users = [
    {
        id: 1,
        username: 'admin',
        // Password is "1234" hashed
        password: '$2a$10$V6rSUrJZq.ZKGDZ1NoI8b.8v8nN9zYTUvD.7Z7QJz5J5z5X5X5X5X'
    }
];

// Login endpoint
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const user = users.find(u => u.username === username);
    
    if (!user) {
        return res.status(401).send('Invalid username or password');
    }

    if (password !== "1234") {
        return res.status(401).send('Invalid username or password');
    
        }
        res.json({ message: 'Login successful', user: { id: user.id, username: user.username } });
    });



// Spare Parts CRUD
app.get('/spare-parts', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM Spare_Part');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/spare-parts', async (req, res) => {
  try {
    const { name, category, quantity, unit_Price } = req.body;
    const total_Price = quantity * unit_Price;
    
    const [result] = await pool.query(
      'INSERT INTO Spare_Part (name, category, quantity, unit_Price, total_Price) VALUES (?, ?, ?, ?, ?)',
      [name, category, quantity, unit_Price, total_Price]
    );
    
    const [newPart] = await pool.query('SELECT * FROM Spare_Part WHERE id = ?', [result.insertId]);
    res.json(newPart[0]);
  } catch (err) {
    res.status(500).json({ 
      error: 'Failed to add spare part',
      details: err.message,
      sqlMessage: err.sqlMessage 
    });
  }
});

// Stock In - Corrected column names
app.get('/stock-in', async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT si.*, sp.name as part_name 
      FROM Stock_In si
      JOIN Spare_Part sp ON si.spare_part_id = sp.id
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/stock-in', async (req, res) => {
  try {
    const { partId, quantity } = req.body;
    const currentDate = new Date().toISOString().slice(0, 19).replace('T', ' ');
    
    // Using correct column names from schema
    const [result] = await pool.query(
      'INSERT INTO Stock_In (spare_part_id, stock_in_quantity, stock_in_date) VALUES (?, ?, ?)',
      [partId, quantity, currentDate]
    );
    
    // Update spare part quantity
    await pool.query(
      'UPDATE Spare_Part SET quantity = quantity + ?, total_Price = quantity * unit_Price WHERE id = ?',
      [quantity, partId]
    );
    
    const [newStockIn] = await pool.query(`
      SELECT si.*, sp.name as part_name 
      FROM Stock_In si
      JOIN Spare_Part sp ON si.spare_part_id = sp.id
      WHERE si.id = ?
    `, [result.insertId]);
    
    res.json(newStockIn[0]);
  } catch (err) {
    res.status(500).json({ 
      error: 'Failed to add stock in',
      details: err.message,
      sqlMessage: err.sqlMessage 
    });
  }
});

// Stock Out - Updated to match exact table schema
app.get('/stock-out', async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT 
        so.id,
        so.spare_part_id as partId,
        so.stock_out_quantity as quantity,
        so.stock_out_unit_price as unit_price,
        so.stock_out_total_price as total_price,
        so.stock_out_date as date,
        sp.name as part_name 
      FROM Stock_Out so
      JOIN Spare_Part sp ON so.spare_part_id = sp.id
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/stock-out', async (req, res) => {
  try {
    const { partId, quantity, unit_price } = req.body;
    const total_price = quantity * unit_price;
    const currentDate = new Date().toISOString().slice(0, 19).replace('T', ' ');
    
    // Using exact column names from table schema
    const [result] = await pool.query(
      'INSERT INTO Stock_Out (spare_part_id, stock_out_quantity, stock_out_unit_price, stock_out_total_price, stock_out_date) VALUES (?, ?, ?, ?, ?)',
      [partId, quantity, unit_price, total_price, currentDate]
    );
    
    // Update spare part quantity
    await pool.query(
      'UPDATE Spare_Part SET quantity = quantity - ?, total_Price = quantity * unit_Price WHERE id = ?',
      [quantity, partId]
    );
    
    const [newStockOut] = await pool.query(`
      SELECT so.*, sp.name as part_name 
      FROM Stock_Out so
      JOIN Spare_Part sp ON so.spare_part_id = sp.id
      WHERE so.id = ?
    `, [result.insertId]);
    
    res.json(newStockOut[0]);
  } catch (err) {
    res.status(500).json({ 
      error: 'Failed to add stock out',
      details: err.message,
      sqlMessage: err.sqlMessage 
    });
  }
});

// Reports
app.get('/reports/stock-status', async (req, res) => {
  try {
    const [parts] = await pool.query('SELECT * FROM Spare_Part');
    const [outs] = await pool.query(`
      SELECT spare_part_id, SUM(stock_out_quantity) as totalOut 
      FROM Stock_Out 
      GROUP BY spare_part_id
    `);
    
    const status = parts.map(part => {
      const out = outs.find(o => o.spare_part_id === part.id);
      return {
        id: part.id,
        name: part.name,
        category: part.category,
        currentQuantity: part.quantity,
        unitPrice: part.unit_Price,
        totalPrice: part.total_Price,
        totalOut: out ? out.totalOut : 0
      };
    });
    
    res.json(status);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ======================
// Spare Parts - Update & Delete
// ======================
app.put('/spare-parts/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, category, quantity, unit_Price } = req.body;
    const total_Price = quantity * unit_Price;

    // First update the spare part
    await pool.query(
      'UPDATE Spare_Part SET name = ?, category = ?, quantity = ?, unit_Price = ?, total_Price = ? WHERE id = ?',
      [name, category, quantity, unit_Price, total_Price, id]
    );

    // Then get the updated record
    const [updatedPart] = await pool.query('SELECT * FROM Spare_Part WHERE id = ?', [id]);
    
    res.json(updatedPart[0]);
  } catch (err) {
    res.status(500).json({ 
      error: 'Failed to update spare part',
      details: err.message,
      sqlMessage: err.sqlMessage 
    });
  }
});

app.delete('/spare-parts/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // First check if there are any stock in/out records referencing this part
    const [stockInRefs] = await pool.query('SELECT COUNT(*) as count FROM Stock_In WHERE spare_part_id = ?', [id]);
    const [stockOutRefs] = await pool.query('SELECT COUNT(*) as count FROM Stock_Out WHERE spare_part_id = ?', [id]);
    
    if (stockInRefs[0].count > 0 || stockOutRefs[0].count > 0) {
      return res.status(400).json({ 
        error: 'Cannot delete part with existing stock records',
        solution: 'Delete associated stock records first'
      });
    }

    await pool.query('DELETE FROM Spare_Part WHERE id = ?', [id]);
    res.json({ message: 'Spare part deleted successfully' });
  } catch (err) {
    res.status(500).json({ 
      error: 'Failed to delete spare part',
      details: err.message,
      sqlMessage: err.sqlMessage 
    });
  }
});

// ======================
// Stock In - Update & Delete
// ======================
app.put('/stock-in/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { spare_part_id, stock_in_quantity } = req.body;
    
    // First get the original record to calculate quantity difference
    const [originalRecord] = await pool.query('SELECT * FROM Stock_In WHERE id = ?', [id]);
    
    if (!originalRecord[0]) {
      return res.status(404).json({ error: 'Stock in record not found' });
    }

    const quantityDiff = stock_in_quantity - originalRecord[0].stock_in_quantity;
    
    // Start transaction
    const conn = await pool.getConnection();
    await conn.beginTransaction();

    try {
      // Update the stock in record
      await conn.query(
        'UPDATE Stock_In SET spare_part_id = ?, stock_in_quantity = ? WHERE id = ?',
        [spare_part_id, stock_in_quantity, id]
      );

      // Update the spare part quantity
      await conn.query(
        'UPDATE Spare_Part SET quantity = quantity + ?, total_Price = quantity * unit_Price WHERE id = ?',
        [quantityDiff, spare_part_id]
      );

      await conn.commit();
      
      // Get the updated record with part name
      const [updatedRecord] = await pool.query(`
        SELECT si.*, sp.name as part_name 
        FROM Stock_In si
        JOIN Spare_Part sp ON si.spare_part_id = sp.id
        WHERE si.id = ?
      `, [id]);
      
      res.json(updatedRecord[0]);
    } catch (err) {
      await conn.rollback();
      throw err;
    } finally {
      conn.release();
    }
  } catch (err) {
    res.status(500).json({ 
      error: 'Failed to update stock in record',
      details: err.message,
      sqlMessage: err.sqlMessage 
    });
  }
});

app.delete('/stock-in/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // First get the record to know how much to subtract
    const [record] = await pool.query('SELECT * FROM Stock_In WHERE id = ?', [id]);
    
    if (!record[0]) {
      return res.status(404).json({ error: 'Stock in record not found' });
    }

    const quantity = record[0].stock_in_quantity;
    const partId = record[0].spare_part_id;
    
    // Start transaction
    const conn = await pool.getConnection();
    await conn.beginTransaction();

    try {
      // Delete the stock in record
      await conn.query('DELETE FROM Stock_In WHERE id = ?', [id]);

      // Update the spare part quantity
      await conn.query(
        'UPDATE Spare_Part SET quantity = quantity - ?, total_Price = quantity * unit_Price WHERE id = ?',
        [quantity, partId]
      );

      await conn.commit();
      res.json({ message: 'Stock in record deleted successfully' });
    } catch (err) {
      await conn.rollback();
      throw err;
    } finally {
      conn.release();
    }
  } catch (err) {
    res.status(500).json({ 
      error: 'Failed to delete stock in record',
      details: err.message,
      sqlMessage: err.sqlMessage 
    });
  }
});

// ======================
// Stock Out - Update & Delete
// ======================
app.put('/stock-out/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { partId, quantity, unit_price } = req.body;
    const total_price = quantity * unit_price;
    
    // First get the original record to calculate quantity difference
    const [originalRecord] = await pool.query('SELECT * FROM Stock_Out WHERE id = ?', [id]);
    
    if (!originalRecord[0]) {
      return res.status(404).json({ error: 'Stock out record not found' });
    }

    const quantityDiff = quantity - originalRecord[0].stock_out_quantity;
    
    // Start transaction
    const conn = await pool.getConnection();
    await conn.beginTransaction();

    try {
      // Update the stock out record
      await conn.query(
        'UPDATE Stock_Out SET spare_part_id = ?, stock_out_quantity = ?, stock_out_unit_price = ?, stock_out_total_price = ? WHERE id = ?',
        [partId, quantity, unit_price, total_price, id]
      );

      // Update the spare part quantity
      await conn.query(
        'UPDATE Spare_Part SET quantity = quantity + ?, total_Price = quantity * unit_Price WHERE id = ?',
        [-quantityDiff, partId] // Note the negative sign for stock out
      );

      await conn.commit();
      
      // Get the updated record with part name
      const [updatedRecord] = await pool.query(`
        SELECT 
          so.id,
          so.spare_part_id as partId,
          so.stock_out_quantity as quantity,
          so.stock_out_unit_price as unit_price,
          so.stock_out_total_price as total_price,
          so.stock_out_date as date,
          sp.name as part_name 
        FROM Stock_Out so
        JOIN Spare_Part sp ON so.spare_part_id = sp.id
        WHERE so.id = ?
      `, [id]);
      
      res.json(updatedRecord[0]);
    } catch (err) {
      await conn.rollback();
      throw err;
    } finally {
      conn.release();
    }
  } catch (err) {
    res.status(500).json({ 
      error: 'Failed to update stock out record',
      details: err.message,
      sqlMessage: err.sqlMessage 
    });
  }
});

app.delete('/stock-out/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // First get the record to know how much to add back
    const [record] = await pool.query('SELECT * FROM Stock_Out WHERE id = ?', [id]);
    
    if (!record[0]) {
      return res.status(404).json({ error: 'Stock out record not found' });
    }

    const quantity = record[0].stock_out_quantity;
    const partId = record[0].spare_part_id;
    
    // Start transaction
    const conn = await pool.getConnection();
    await conn.beginTransaction();

    try {
      // Delete the stock out record
      await conn.query('DELETE FROM Stock_Out WHERE id = ?', [id]);

      // Update the spare part quantity (add back the stock out quantity)
      await conn.query(
        'UPDATE Spare_Part SET quantity = quantity + ?, total_Price = quantity * unit_Price WHERE id = ?',
        [quantity, partId]
      );

      await conn.commit();
      res.json({ message: 'Stock out record deleted successfully' });
    } catch (err) {
      await conn.rollback();
      throw err;
    } finally {
      conn.release();
    }
  } catch (err) {
    res.status(500).json({ 
      error: 'Failed to delete stock out record',
      details: err.message,
      sqlMessage: err.sqlMessage 
    });
  }
});

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});